package com.enr_operational.utilities;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MasterTableBean {
	private String sNo;
	private String existingAccountName = "";
	private String organizationType = "";
	private String typeOfTR = "";
	private String tRName = "";
	private String tRStatus = "A";
	private String lastUpdatedDate = "";
	private String lastUpdatedBy = "";

	public String getsNo() {
		return sNo;
	}

	public void setsNo(String sNo) {
		this.sNo = sNo;
	}

	public String getExistingAccountName() {
		return existingAccountName;
	}

	public void setExistingAccountName(String existingAccountName) {
		this.existingAccountName = existingAccountName;
	}

	public String getOrganizationType() {
		return organizationType;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}

	public String getTypeOfTR() {
		return typeOfTR;
	}

	public void setTypeOfTR(String typeOfTR) {
		this.typeOfTR = typeOfTR;
	}

	public String gettRName() {
		return tRName;
	}

	public void settRName(String tRName) {
		this.tRName = tRName;
	}

	public String gettRStatus() {
		return tRStatus;
	}

	public void settRStatus(String tRStatus) {
		this.tRStatus = tRStatus;
	}

	public String getLastUpdatedDate() {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd/uuuu");
		LocalDate date = LocalDate.now();
		String strDate = date.format(formatters);
		this.lastUpdatedDate = strDate;
		return lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		String[] cred = Credentials.getCredentials();
		this.lastUpdatedBy = cred[0];
		return lastUpdatedBy;
	}
}
