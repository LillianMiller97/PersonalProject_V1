package com.enr_operational.utilities;

import java.awt.Button;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonSeleniumUtils extends Driver {

	public void switchToWindowByTitle(String title) {
		Set<String> windows = Driver.getDriver().getWindowHandles();
		System.out.println("Amount of windows that are currently present :: " + windows.size());
		for (String window : windows) {
			Driver.getDriver().switchTo().window(window);
			if (Driver.getDriver().getTitle().startsWith(title)
					|| Driver.getDriver().getTitle().equalsIgnoreCase(title)) {
				break;
			} else {
				continue;
			}
		}
	}

	public void clickWithJS(WebElement elementtoclick) {
		WebDriverWait wait = new WebDriverWait(Driver.getDriver(),
				Long.parseLong(ConfigurationReader.getProperty("timeout")));
		wait.until(ExpectedConditions.elementToBeClickable(elementtoclick));
		((JavascriptExecutor) Driver.getDriver()).executeScript("arguments[0].scrollIntoView(true);", elementtoclick);
		((JavascriptExecutor) Driver.getDriver()).executeScript("arguments[0].click();", elementtoclick);
	}

	public void waitForPresenceOfElementByCss(String css) {
		WebDriverWait wait = new WebDriverWait(Driver.getDriver(),
				Long.parseLong(ConfigurationReader.getProperty("timeout")));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(css)));
	}

	public void waitForVisibilityOfElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(Driver.getDriver(),
				Long.parseLong(ConfigurationReader.getProperty("timeout")));
		wait.until(ExpectedConditions.visibilityOf(element));
	}

//	public void waitForVisibilityOfElements(WebElement element, WebElement element2) {
//		WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(ConfigurationReader.getProperty("timeout")));
//		wait.until(ExpectedConditions.visibilityOf(element));
//	}

	public void waitForStaleElement(WebElement element) {
		int i = 0;
		while (i < 10) {
			try {
				element.isDisplayed();
				break;
			} catch (StaleElementReferenceException e) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e1) {
//				 System.out.println("InterruptedException is handled "+e1);
				}
//				System.out.println("StaleElementReferenceException is handled "+e);
				i++;
			} catch (NoSuchElementException e) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e1) {
//					System.out.println("InterruptedException is handled "+e1);
				}
//				System.out.println("NoSuchElementException is handled "+e);
				i++;
			} catch (WebDriverException e) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e1) {
//					System.out.println("InterruptedException is handled "+e1);
				}
//				System.out.println("WebDriverException is handled "+e);
				i++;
			}
		}
	}

	public boolean verifyElementIsNotPresent(String xpath) {
		List<WebElement> elemetns = Driver.getDriver().findElements(By.xpath(xpath));
		return elemetns.size() == 0;
	}

	public boolean verifyElementIsNotPresent(By by) {
		List<WebElement> elemetns = Driver.getDriver().findElements(by);
		return elemetns.size() == 0;
	}

	public void scrollToElement(WebElement element) {
		((JavascriptExecutor) Driver.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void hitEnterUsingRobot() {
		Robot rb;
		try {
			rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean verifyAlertPresent() {
		try {
			Driver.getDriver().switchTo().alert();
			return true;
		} catch (NoAlertPresentException Ex) {
			System.out.println("Alert is not presenet");
		}
		return false;
	}

	public boolean isElementVisible(By arg0) {
		boolean elementVisible = false;
		try {
			(new WebDriverWait(Driver.getDriver(), 60)).until(ExpectedConditions.visibilityOfElementLocated(arg0));
			elementVisible = true;

		} catch (TimeoutException ex) {
			elementVisible = false;
		}
		return elementVisible;
	}

	public void InitilizaButton() {
		Button createAccountbutton = new Button("createAccount");
		Button validationButton = new Button("validationBtn");

		validationButton.setEnabled(false);
	}
}
