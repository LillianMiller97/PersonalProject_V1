package com.enr_operational.utilities;

import java.io.File;
import java.io.FileInputStream;

import java.io.FileOutputStream;

import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.List;

import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.ss.usermodel.CellStyle;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;

import org.apache.poi.xssf.usermodel.XSSFFont;

import org.apache.poi.xssf.usermodel.XSSFRow;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils
 {
//	private XSSFSheet workSheet;
//	private XSSFWorkbook workBook;

	Workbook workBook;
	Sheet workSheet;
	
	private String path;

	public ExcelUtils(String path, String sheetName)  {

		this.path = path;

		try {
			// Open the Excel file
			//FileInputStream ExcelFile = new FileInputStream(path);
			// Access the required test data sheet
			// workBook = new XSSFWorkbook(ExcelFile);
			//workBook = new XSSFWorkbook(new File(path));
			// workSheet = workBook.getSheet(sheetName);
			
			FileInputStream file = new FileInputStream(new File(path));
			workBook = WorkbookFactory.create(file);
			workSheet = workBook.getSheet(sheetName);
		} catch (IOException | EncryptedDocumentException | InvalidFormatException e) {

			throw new RuntimeException(e);

		} 

	}

	public int getRowCount(String sheetName) {

		int index = workBook.getSheetIndex(sheetName);

		if (index == -1)

			return 0;

		else {

			workSheet = workBook.getSheetAt(index);

			int number = workSheet.getLastRowNum() + 1;

			return number;

		}

	}

	public String getCellData(int rowNum, int colNum) {

		Cell cell;

		try {

			cell = workSheet.getRow(rowNum).getCell(colNum);

			String cellData = cell.toString();

			return cellData;

		} catch (Exception e) {

		//	e.printStackTrace();

			return "";

		}

	}

	public String[][] getDataArray() {

		String[][] data = new String[rowCount()][columnCount()];

		for (int i = 0; i < rowCount(); i++) {

			for (int j = 0; j < columnCount(); j++) {

				String value = getCellData(i, j);

				data[i][j] = value;

			}

		}

		return data;

	}

	public List<Map<String, String>> getDataList() {

		// get all columns

		List<String> columns = getColumnsNames();

		// this will be returned

		List<Map<String, String>> data = new ArrayList<Map<String, String>>();

		for (int i = 1; i < rowCount(); i++) {

			// get each row

			Row row = workSheet.getRow(i);

			// create map of the row using the column and value

			// column map key, cell value --> map bvalue

			Map<String, String> rowMap = new HashMap<String, String>();
			for (Cell cell : row) {
				int columnIndex = cell.getColumnIndex();
				rowMap.put(columns.get(columnIndex), cell.toString());
			}
			data.add(rowMap);
		}
		return data;

	}

	public List<String> getColumnsNames() {
		List<String> columns = new ArrayList<String>();
		Row row = workSheet.getRow(0);
		for (Cell cell : row) {
			columns.add(cell.toString());
		}
		return columns;

	}

	public void setCellData(String value, int rowNum, int colNum) {
		Cell cell;
		Row row;

		try {
			row = workSheet.getRow(rowNum);
			if (row == null) {
				row = workSheet.createRow(rowNum);
			}
			cell = row.getCell(colNum);

			if (cell == null) {
				cell = row.createCell(colNum);
				cell.setCellValue(value);
			} else {
				cell.setCellValue(value);
			}
			FileOutputStream fileOut = new FileOutputStream(path);
			workBook.write(fileOut);
			fileOut.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public Cell getCell(int rowNum, int colNum) {
		Cell cell;
		Row row;
		try {
			row = workSheet.getRow(rowNum);

			if (row == null) {
				System.out.println("here");
				row = workSheet.createRow(rowNum);
				cell = row.createCell(colNum);
				System.out.println(cell);
				return cell;
			}

			cell = row.getCell(colNum);
			return cell;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}

	}

	public void setCellData(String value, String columnName, int row) {
		int column = getColumnsNames().indexOf(columnName);
		setCellData(value, row, column);
	}

	public int columnCount() {
		return workSheet.getRow(0).getLastCellNum();

	}

	public int rowCount() {
		return workSheet.getPhysicalNumberOfRows();

	}

	public CellStyle getCellStyle() {
		CellStyle cellStyle = workBook.createCellStyle();
		cellStyle.setDataFormat(workBook.getCreationHelper().createDataFormat().getFormat("###,###"));
		Font font = workBook.createFont();
		font.setColor(HSSFColor.HSSFColorPredefined.GREEN.getIndex());
		cellStyle.setFont(font);
		return cellStyle;

	}

	public void writeAccountToExcel(AccountBean account) {
		System.out.println("Saving " + account.getShortName() + " account data to Excel");
		CellStyle style = getStyle();

		int row = getIndexBlankRow();
		account.setsNo(String.valueOf(getIndexBlankRow() - 1));

		this.setCellData(account.getsNo(), row, 0);
		this.getCell(row, 0).setCellType(CellType.STRING);
		this.getCell(row, 0).setCellStyle(style);

		this.setCellData(account.getActionFlag(), row, 1);
		this.getCell(row, 1).setCellType(CellType.STRING);
		this.getCell(row, 1).setCellStyle(style);

		this.setCellData(account.getExecutionStatus(), row, 2);
		this.getCell(row, 2).setCellType(CellType.STRING);
		this.getCell(row, 2).setCellStyle(style);

		this.setCellData(account.getShortName(), row, 3);
		this.getCell(row, 3).setCellType(CellType.STRING);
		this.getCell(row, 3).setCellStyle(style);

		this.setCellData(account.getName(), row, 4);
		this.getCell(row, 4).setCellType(CellType.STRING);
		this.getCell(row, 4).setCellStyle(style);

		this.setCellData(account.getOrganizationType(), row, 5);
		this.getCell(row, 5).setCellType(CellType.STRING);
		this.getCell(row, 5).setCellStyle(style);

		this.setCellData(account.getParentAccount(), row, 6);
		this.getCell(row, 6).setCellType(CellType.STRING);
		this.getCell(row, 6).setCellStyle(style);

		this.setCellData(account.getContext(), row, 7);
		this.getCell(row, 7).setCellType(CellType.STRING);
		this.getCell(row, 7).setCellStyle(style);

		this.setCellData(account.getRole(), row, 8);
		this.getCell(row, 8).setCellType(CellType.STRING);
		this.getCell(row, 8).setCellStyle(style);

		this.setCellData(account.getAccountIdentifierValue(), row, 9);
		this.getCell(row, 9).setCellType(CellType.STRING);
		this.getCell(row, 9).setCellStyle(style);

		this.getCell(row, 10).setCellType(CellType.STRING);
		this.getCell(row, 10).setCellStyle(style);

		System.out.println(account.getShortName() + " account is saved.");

	}

	public void writeTradeRelationshipData(TradeRelationship_Bean tr) {
		CellStyle style = getStyle();

		System.out.println("Saving TR to Excel..");
		int row = getIndexBlankRow();
		tr.setsNo(String.valueOf(row - 1));

		this.setCellData(tr.getsNo(), row, 0);
		this.getCell(row, 0).setCellType(CellType.STRING);
		this.getCell(row, 0).setCellStyle(style);

		this.setCellData(tr.getActionFlag(), row, 1);
		this.getCell(row, 1).setCellType(CellType.STRING);
		this.getCell(row, 1).setCellStyle(style);

		this.setCellData(tr.gettRType(), row, 2);
		this.getCell(row, 2).setCellType(CellType.STRING);
		this.getCell(row, 2).setCellStyle(style);

		this.setCellData(tr.getAccountShortName(), row, 3);
		this.getCell(row, 3).setCellType(CellType.STRING);
		this.getCell(row, 3).setCellStyle(style);

		this.setCellData(tr.getInBoundTRName(), row, 4);
		this.getCell(row, 4).setCellType(CellType.STRING);
		this.getCell(row, 4).setCellStyle(style);

		this.setCellData(tr.getOutBoundTRName(), row, 5);
		this.getCell(row, 5).setCellType(CellType.STRING);
		this.getCell(row, 5).setCellStyle(style);

		this.setCellData(tr.gettRCategory(), row, 6);
		this.getCell(row, 6).setCellType(CellType.STRING);
		this.getCell(row, 6).setCellStyle(style);

		this.setCellData(tr.getThirdPartyAgent(), row, 7);
		this.getCell(row, 7).setCellType(CellType.STRING);
		this.getCell(row, 7).setCellStyle(style);

		this.setCellData(tr.getAgentTradeRelationship(), row, 8);
		this.getCell(row, 8).setCellType(CellType.STRING);
		this.getCell(row, 8).setCellStyle(style);

		this.setCellData(tr.getMode(), row, 9);
		this.getCell(row, 9).setCellType(CellType.STRING);
		this.getCell(row, 9).setCellStyle(style);

		this.setCellData(tr.getSchedulerFrequency(), row, 10);
		this.getCell(row, 10).setCellType(CellType.STRING);
		this.getCell(row, 10).setCellStyle(style);

		this.setCellData(tr.getSchedulerValue(), row, 11);
		this.getCell(row, 11).setCellType(CellType.STRING);
		this.getCell(row, 11).setCellStyle(style);

		this.setCellData(tr.getNextActivityOn(), row, 12);
		this.getCell(row, 12).setCellType(CellType.STRING);
		this.getCell(row, 12).setCellStyle(style);

		this.setCellData(tr.getSchedulerSetting(), row, 13);
		this.getCell(row, 13).setCellType(CellType.STRING);
		this.getCell(row, 13).setCellStyle(style);

		this.setCellData(tr.getFullFileScope(), row, 14);
		this.getCell(row, 14).setCellType(CellType.STRING);
		this.getCell(row, 14).setCellStyle(style);

		this.setCellData(tr.getDivisionList(), row, 15);
		this.getCell(row, 15).setCellType(CellType.STRING);
		this.getCell(row, 15).setCellStyle(style);

		this.setCellData(tr.getSenderId(), row, 28);
		this.getCell(row, 28).setCellType(CellType.STRING);
		this.getCell(row, 28).setCellStyle(style);
		
		this.setCellData(tr.getAccountIdentifierLocation(), row, 29);
		this.getCell(row, 29).setCellType(CellType.STRING);
		this.getCell(row, 29).setCellStyle(style);
		
		this.setCellData(tr.getInboundStatus(), row, 30);
		this.getCell(row, 30).setCellType(CellType.STRING);
		this.getCell(row, 30).setCellStyle(style);

		this.setCellData(tr.getOutboundStatus(), row, 31);
		this.getCell(row, 31).setCellType(CellType.STRING);
		this.getCell(row, 31).setCellStyle(style);

		System.out.println(" TR is saved");
	}

	private int getIndexBlankRow() {
		int numOfRows = workSheet.getLastRowNum()+1;
		for (int row = 1; row < numOfRows; row++) {
			Cell cell = this.getCell(row, 0);
			cell.setCellType(CellType.STRING);
			if (cell == null || cell.getStringCellValue() == null || cell.getStringCellValue().equals("")) {
				return row;
			}
		}
		return numOfRows;
	}

	public void writeContactToAccount(String accountShortName, ContactBean contact) {
		CellStyle style = getStyle();
		System.out.println("Saving contact to excel..");
		int row = getAccountRowIndex(accountShortName);
		int dynamicIndex = getAvailableContact(row);

		int column = 11 + dynamicIndex;
		this.setCellData(contact.getFirstName(), row, column);
		this.getCell(row, column).setCellType(CellType.STRING);
		this.getCell(row, column).setCellStyle(style);

		column = 12 + dynamicIndex;
		this.setCellData(contact.getLastName(), row, column);
		this.getCell(row, column).setCellType(CellType.STRING);
		this.getCell(row, column).setCellStyle(style);

		column = 13 + dynamicIndex;
		this.setCellData(contact.getPhone(), row, column);
		this.getCell(row, column).setCellType(CellType.STRING);
		this.getCell(row, column).setCellStyle(style);

		column = 14 + dynamicIndex;
		this.setCellData(contact.getExt(), row, column);
		this.getCell(row, column).setCellType(CellType.STRING);
		this.getCell(row, column).setCellStyle(style);

		column = 15 + dynamicIndex;
		this.setCellData(contact.getEmail(), row, column);
		this.getCell(row, column).setCellType(CellType.STRING);
		this.getCell(row, column).setCellStyle(style);

		column = 16 + dynamicIndex;
		this.setCellData(contact.getTitle(), row, column);
		this.getCell(row, column).setCellType(CellType.STRING);
		this.getCell(row, column).setCellStyle(style);

		column = 17 + dynamicIndex;
		this.setCellData(contact.getReportSubscription(), row, column);
		this.getCell(row, column).setCellType(CellType.STRING);
		this.getCell(row, column).setCellStyle(style);

		System.out.println("Contact is saved under " + accountShortName + " account");
	}

	public void writeDataToMasterTable(MasterTableBean bean) {
		CellStyle style = getStyle();

		System.out.println("Saving Master Table data to Excel..");
		int row = getIndexBlankRow();
		bean.setsNo(String.valueOf(row));

//		this.setCellData(bean.getsNo(), row, 0);
//		this.getCell(row, 0).setCellType(CellType.STRING);
//		this.getCell(row, 0).setCellStyle(style);

		this.setCellData(bean.getExistingAccountName(), row, 0);
		this.getCell(row, 0).setCellType(CellType.STRING);
		this.getCell(row, 0).setCellStyle(style);

		this.setCellData(bean.getOrganizationType(), row, 1);
		this.getCell(row, 1).setCellType(CellType.STRING);
		this.getCell(row, 1).setCellStyle(style);

		this.setCellData(bean.getTypeOfTR(), row, 2);
		this.getCell(row, 2).setCellType(CellType.STRING);
		this.getCell(row, 2).setCellStyle(style);

		this.setCellData(bean.gettRName(), row, 3);
		this.getCell(row, 3).setCellType(CellType.STRING);
		this.getCell(row, 3).setCellStyle(style);

		this.setCellData(bean.gettRStatus(), row, 4);
		this.getCell(row, 4).setCellType(CellType.STRING);
		this.getCell(row, 4).setCellStyle(style);

		this.setCellData(bean.getLastUpdatedDate(), row, 5);
		this.getCell(row, 5).setCellType(CellType.STRING);
		this.getCell(row, 5).setCellStyle(style);

		this.setCellData(bean.getLastUpdatedBy(), row, 6);
		this.getCell(row, 6).setCellType(CellType.STRING);
		this.getCell(row, 6).setCellStyle(style);

		System.out.println("Data saved to Master Table");

	}

	private int getAccountRowIndex(String accountShortName) {
		int numOfRows = workSheet.getLastRowNum();
		for (int row = 2; row < numOfRows + 1; row++) {
			Cell cell = workSheet.getRow(row).getCell(3);
			System.out.println(cell.getStringCellValue());
			if (cell.getStringCellValue().equalsIgnoreCase(accountShortName)) {
				return row;
			}
		}
		throw new RuntimeException("Error during getting index of account " + accountShortName);
	}

	private int getAvailableContact(int accountRow) {
		Cell cell = workSheet.getRow(accountRow).getCell(11);
		if (cell == null || cell.getStringCellValue() == null || cell.getStringCellValue().equals("")) {
			System.out.println("First contact is available");
			return 0;
		}

		cell = workSheet.getRow(accountRow).getCell(18);
		if (cell == null || cell.getStringCellValue() == null || cell.getStringCellValue().equals("")) {
			System.out.println("Second contact is available");
			return 7;
		}

		cell = workSheet.getRow(accountRow).getCell(25);
		if (cell == null || cell.getStringCellValue() == null || cell.getStringCellValue().equals("")) {
			System.out.println("Third contact is available");
			return 14;
		}

		System.out.println("All contacts are occupaid. Overriding first contact");
		return 0;
	}

	public CellStyle getStyle() {
		CellStyle style = workBook.createCellStyle();
		style.setWrapText(true);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		style.setAlignment(HorizontalAlignment.CENTER);
		return style;
	}
	
	public Map<String,AccountBean> acMaping = new HashMap<>();
	public List<AccountBean> getAccountData() {
		List<AccountBean> accountData = new ArrayList<>();
		String[][] data = this.getDataArray();
		
		for(int i = 2; i < data.length; i++) {
			System.out.println(data[i][3]);
			if(data[i][3].isEmpty() || data[i][3].equalsIgnoreCase("IF(ISBLANK($B4),\"\",\"--Please Enter Unique Name for Account--\")")) {
				break;
			}
			
			AccountBean account = new AccountBean();
			account.setActionFlag(data[i][1]);
			account.setShortName(data[i][3]);
			account.setName(data[i][4]);
			account.setOrganizationType(data[i][5]);
			account.setParentAccount(data[i][6]);
			account.setContext(data[i][7]);
			account.setRole(data[i][8]);
			account.setAccountIdentifierValue(data[i][9]);
			account.setOtherIdentifier(data[i][10]);
			account.setContacts(getContacts(data,i));
			accountData.add(account);
			acMaping.put(account.getShortName(), account);
		}
		
		return accountData;
	}
	
	private List<ContactBean> getContacts(String[][] data, int rowIndex){
		List<ContactBean> contacts = new ArrayList<>();
		int dynamicIndex = 0;
		for(int j = 0; j < 3; j++) {			
			if(!data[rowIndex][11+dynamicIndex].isEmpty() && !data[rowIndex][12+dynamicIndex].isEmpty()) {
				ContactBean contact = new ContactBean();
				contact.setFirstName(data[rowIndex][11+dynamicIndex]);
				contact.setLastName(data[rowIndex][12+dynamicIndex]);
				contact.setPhone(data[rowIndex][13+dynamicIndex]);
				contact.setExt(data[rowIndex][14+dynamicIndex]);
				contact.setEmail(data[rowIndex][15+dynamicIndex]);
				contact.setTitle(data[rowIndex][16+dynamicIndex]);
				contact.setReportSubscription(data[rowIndex][17+dynamicIndex]);
				contacts.add(contact);
			}
			dynamicIndex += 7;
		}
		return contacts;
	}
	
	public List<TradeRelationship_Bean> getTradeRelData(){
		List<TradeRelationship_Bean> trData = new ArrayList<>();
		String[][] data = this.getDataArray();
		
		for(int i = 2; i < data.length; i++) {
			TradeRelationship_Bean trBean = new TradeRelationship_Bean();
			trBean.setActionFlag(data[i][1]);
			trBean.settRType(data[i][2]);
			trBean.setAccountShortName(data[i][3]);
			trBean.setInBoundTRName(data[i][4]);
			trBean.setOutBoundTRName(data[i][5]);
			trBean.settRCategory(data[i][6]);
			trBean.setThirdPartyAgent(data[i][7]);
			trBean.setAgentTradeRelationship(data[i][8]);
			trBean.setMode(data[i][9]);
			trBean.setSchedulerFrequency(data[i][10]);
			trBean.setSchedulerValue(data[i][11]);																																																				
			trBean.setFullFileScope(data[i][14]);
			
			trBean.setSenderId(data[i][29]);
			trBean.setAccountIdentifierLocation(data[i][28]);
			trData.add(trBean);
			
		}
		
		return trData;
	}
	
	public static void main(String[] args) {
		String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");
		excelUtils.getTradeRelData();	
	}
	
}
