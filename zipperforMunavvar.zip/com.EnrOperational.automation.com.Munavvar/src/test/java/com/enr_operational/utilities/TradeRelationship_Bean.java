package com.enr_operational.utilities;

public class TradeRelationship_Bean {

	private String sNo;
	private String actionFlag = "C";
	private String tRType = "";
	private String accountShortName = "";
	private String inBoundTRName = actionFlag.equalsIgnoreCase("C") ? "--Not Applicable for TR Creation--"
			: actionFlag.equalsIgnoreCase("T") ? "--Please Select TR to be Terminated--" : "";
	private String outBoundTRName = actionFlag.equalsIgnoreCase("C") ? "--Not Applicable for TR Creation--"
			: actionFlag.equalsIgnoreCase("T") ? "--Please Select TR to be Terminated--" : "";;
	private String tRCategory = "";
	private String thirdPartyAgent = "";
	private String agentTradeRelationship = "";
	private String mode = "Limited Production";
	private String schedulerFrequency = "Weekly";
	private String schedulerValue = "Sunday";
	private String nextActivityOn = "";
	private String schedulerSetting = "";
	private String fullFileScope = "";
	private String divisionList = "BLANK";
	private String senderId = actionFlag.equalsIgnoreCase("C") ? "--Please Enter Sender Id-- " : "";
	private String inboundStatus = "";
	private String outboundStatus = "";
	private String accountIdentifierLocation = "1000A\\N1[04]";
	
	
	public String getAccountIdentifierLocation() {
		return accountIdentifierLocation;
	}

	public void setAccountIdentifierLocation(String accountIdentifierLocation) {
		this.accountIdentifierLocation = accountIdentifierLocation;
	}

	public String getInboundStatus() {
		return inboundStatus;
	}

	public void setInboundStatus(String inboundStatus) {
		this.inboundStatus = inboundStatus;
	}

	public String getOutboundStatus() {
		return outboundStatus;
	}

	public void setOutboundStatus(String outboundStatus) {
		this.outboundStatus = outboundStatus;
	}

	public String getsNo() {
		return sNo;
	}

	public void setsNo(String sNo) {
		this.sNo = sNo;
	}

	public String getActionFlag() {
		return actionFlag;
	}

	public void setActionFlag(String actionFlag) {
		this.actionFlag = actionFlag;
	}

	public String gettRType() {
		return tRType;
	}

	public void settRType(String tRType) {
		this.tRType = tRType;
	}

	public String getAccountShortName() {
		return accountShortName;
	}

	public void setAccountShortName(String accountShortName) {
		this.accountShortName = accountShortName;
	}

	public String getInBoundTRName() {
		return inBoundTRName;
	}

	public void setInBoundTRName(String inBoundTRName) {
		this.inBoundTRName = inBoundTRName;
	}

	public String getOutBoundTRName() {
		return outBoundTRName;
	}

	public void setOutBoundTRName(String outBoundTRName) {
		this.outBoundTRName = outBoundTRName;
	}

	public String gettRCategory() {
		return tRCategory;
	}

	public void settRCategory(String tRCategory) {
		this.tRCategory = tRCategory;
	}

	public String getThirdPartyAgent() {
		return thirdPartyAgent;
	}

	public void setThirdPartyAgent(String thirdPartyAgent) {
		this.thirdPartyAgent = thirdPartyAgent;
	}

	public String getAgentTradeRelationship() {
		return agentTradeRelationship;
	}

	public void setAgentTradeRelationship(String agentTradeRelationship) {
		this.agentTradeRelationship = agentTradeRelationship;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getSchedulerFrequency() {
		return schedulerFrequency;
	}

	public void setSchedulerFrequency(String schedulerFrequency) {
		this.schedulerFrequency = schedulerFrequency;
	}

	public String getSchedulerValue() {
		return schedulerValue;
	}

	public void setSchedulerValue(String schedulerValue) {
		this.schedulerValue = schedulerValue;
	}

	public String getNextActivityOn() {
		return nextActivityOn;
	}

	public void setNextActivityOn(String nextActivityOn) {
		this.nextActivityOn = nextActivityOn;
	}

	public String getSchedulerSetting() {
		return schedulerSetting;
	}

	public void setSchedulerSetting(String schedulerSetting) {
		this.schedulerSetting = schedulerSetting;
	}

	public String getFullFileScope() {
		return fullFileScope;
	}

	public void setFullFileScope(String fullFileScope) {
		this.fullFileScope = fullFileScope;
	}

	public String getDivisionList() {
		return divisionList;
	}

	public void setDivisionList(String divisionList) {
		this.divisionList = divisionList;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	@Override
	public String toString() {
		return "TradeRelationship_Bean [sNo=" + sNo + ", actionFlag=" + actionFlag + ", tRType=" + tRType
				+ ", accountShortName=" + accountShortName + ", inBoundTRName=" + inBoundTRName + ", outBoundTRName="
				+ outBoundTRName + ", tRCategory=" + tRCategory + ", thirdPartyAgent=" + thirdPartyAgent
				+ ", agentTradeRelationship=" + agentTradeRelationship + ", mode=" + mode + ", schedulerFrequency="
				+ schedulerFrequency + ", schedulerValue=" + schedulerValue + ", nextActivityOn=" + nextActivityOn
				+ ", schedulerSetting=" + schedulerSetting + ", fullFileScope=" + fullFileScope + ", divisionList="
				+ divisionList + ", senderId=" + senderId + ", inboundStatus=" + inboundStatus + ", outboundStatus="
				+ outboundStatus + ", accountIdentifierLocation=" + accountIdentifierLocation + "]";
	}
	
	
}
