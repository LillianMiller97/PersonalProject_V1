package com.enr_operational.utilities;

import java.util.ArrayList;
import java.util.List;

public class AccountBean {
	private String sNo;
	private String actionFlag = "C";
	private String executionStatus = "--No Inputs Required.Please Ignore--";
	private String shortName = "--Please Enter Unique Name for Account--";
	private String name = "--Please Enter Unique Name for Account--";
	private String organizationType = "";
	private String parentAccount = organizationType.equalsIgnoreCase("sub-account") ? "--Please Select Any Accounts--"
			: "--No Inputs Required.Please Ignore--";
	private String context = "External";
	private String role = "Employer Group";
	private String accountIdentifierValue = "";
	private String otherIdentifier = "";
	private List<ContactBean> contacts = null;

	public List<ContactBean> getContacts() {
		return contacts;
	}

	public void setContacts(List<ContactBean> contacts) {
		this.contacts = contacts;
	}

	public String getsNo() {
		return sNo;
	}

	public void setsNo(String sNo) {
		this.sNo = sNo;
	}

	public String getActionFlag() {
		return actionFlag;
	}

	public void setActionFlag(String actionFlag) {
		this.actionFlag = actionFlag;
	}

	public String getExecutionStatus() {
		return executionStatus;
	}

	public void setExecutionStatus(String executionStatus) {
		this.executionStatus = executionStatus;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOrganizationType() {
		return organizationType;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}

	public String getParentAccount() {
		return parentAccount;
	}

	public void setParentAccount(String parentAccount) {
		this.parentAccount = parentAccount;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getAccountIdentifierValue() {
		return accountIdentifierValue;
	}

	public void setAccountIdentifierValue(String accountIdentifierValue) {
		this.accountIdentifierValue = accountIdentifierValue;
	}

	public List<String> getOtherIdentifier() {
		List<String> filtered = new ArrayList<>();
		if (!this.otherIdentifier.isEmpty()) {
			String[] arr = this.otherIdentifier.split(",");
			for (String str : arr) {
				filtered.add(str.trim());
			}
		}
		return filtered;
	}

	public void setOtherIdentifier(String otherIdentifier) {
		this.otherIdentifier = otherIdentifier;
	}

	@Override
	public String toString() {
		return "AccountBean [sNo=" + sNo + ", actionFlag=" + actionFlag + ", executionStatus=" + executionStatus
				+ ", shortName=" + shortName + ", name=" + name + ", organizationType=" + organizationType
				+ ", parentAccount=" + parentAccount + ", context=" + context + ", role=" + role
				+ ", accountIdentifierValue=" + accountIdentifierValue + ", otherIdentifier=" + otherIdentifier + "]";
	}

}
