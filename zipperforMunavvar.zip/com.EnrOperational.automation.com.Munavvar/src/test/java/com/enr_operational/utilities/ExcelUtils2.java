package com.enr_operational.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelUtils2 {
	public static List<List<String>> getExcelData(String pathToFile) {
		List<List<String>> excelData = new ArrayList<List<String>>();
		try {
			FileInputStream iStream = new FileInputStream(pathToFile);
			Workbook workbook = WorkbookFactory.create(iStream);
			Sheet worksheet = workbook.getSheet("Trade Relationship");

			int rowNum = worksheet.getPhysicalNumberOfRows();
			//System.out.println("Number of rows: " + rowNum);

			Row row = worksheet.getRow(1);
			
			int numOfCol = row.getPhysicalNumberOfCells();
			for(int i=0; i < numOfCol; i++) {
				Cell cell = row.getCell(i);
				System.out.println(cell);
			} 
			
			

		    
			workbook.close();
			iStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return excelData;
	}

	public static void main(String[] args) {
		String path = "C:\\Users\\makabi01\\eclipse-workspace\\com.EnrOperational.automation.com\\ENR_Operational_Excel_Updated_1212.xlsx";
		getExcelData(path);
	}
}
