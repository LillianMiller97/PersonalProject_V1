package com.enr_operational.utilities;

public enum ReportSubscriptionType {
	MAINTENANCE(1), SUMMARY(2), MAINTENANCE_DETAIL(3), AUDIT_SUMMARY(4), AUDIT_DETAIL(5);

	private int numValue;

	ReportSubscriptionType(int numValue) {
		this.numValue = numValue;
	}

	public int getNumValue() {
		return numValue;
	}
}
