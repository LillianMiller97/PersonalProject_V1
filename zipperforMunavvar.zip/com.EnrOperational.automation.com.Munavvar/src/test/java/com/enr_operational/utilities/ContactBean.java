package com.enr_operational.utilities;

import java.util.ArrayList;
import java.util.List;

public class ContactBean {
	private String firstName = "";
	private String lastName = "";
	private String phone = "";
	private String ext = "";
	private String email = "";
	private String title = "";
	private String reportSubscription = "";

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getExt() {
		return ext;
	}

	public void setExt(String ext) {
		this.ext = ext;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getReportSubscription() {
		return this.reportSubscription.substring(0, this.reportSubscription.length()-1);
	}

	public void setReportSubscription(ReportSubscriptionType... reportSubscriptionTypes) {
		for(ReportSubscriptionType rsType: reportSubscriptionTypes) {
			this.reportSubscription += String.valueOf(rsType.getNumValue())+",";
		} 
	}
	
	public void setReportSubscription(String reportSubscription) {
		this.reportSubscription = reportSubscription;
	}
	
	public List<String> getReportSubscriptionList() {
		List<String> filteredSubscription = new ArrayList<>();
		if(!this.reportSubscription.isEmpty()) {
			String[] arr = this.reportSubscription.split(",");
			
			for(String str : arr) {
				if(!str.isEmpty()) {
					filteredSubscription.add(str.trim());
				}			
			}
		}	
		return filteredSubscription;
	}
	
}
