package com.enr_operational.utilities;

public enum MessageType {
	 WARNING, SUCCESS, INFO, ERROR;
}
