package com.enr_operational.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.enr_operational.tests.TestBase;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.CommonSeleniumUtils;
import com.enr_operational.utilities.ConfigurationReader;
import com.enr_operational.utilities.Credentials;
import com.enr_operational.utilities.Driver;
import com.enroperation.identifiers.LoginPageIdentifier;

public class LoginPage extends TestBase {
	// CommonSeleniumUtils util = new CommonSeleniumUtils();

	public LoginPage() {
		PageFactory.initElements(Driver.getDriver(), this);
	}

	@FindBy(id = LoginPageIdentifier.userNameIdentifierID)
	public WebElement username;

	@FindBy(xpath = LoginPageIdentifier.passwordIdentifierXpath)
	public WebElement password;

	@FindBy(css = LoginPageIdentifier.loginButtonIdentifierCss)
	public WebElement loginButton;

	public void loginApplication() throws Exception {
		String[] cred = Credentials.getCredentials();
//		username.sendKeys(ConfigurationReader.getProperty("username"));
//		password.sendKeys(ConfigurationReader.getProperty("password"));
		username.sendKeys(cred[0]);
		password.sendKeys(cred[1]);
		imgpath = BrowserUtils.CaptureScreenshot("Login.html");
		System.out.println(imgpath);
		loginButton.click();

		System.out.println(Driver.getDriver().getTitle());
	}

	String actualTitle = "CommerceDesk_MainFrame";

	public void verifyTitle(String title) {
		actualTitle = title;
		System.out.println(actualTitle);
		Assert.assertEquals(actualTitle, title);
	}

}
