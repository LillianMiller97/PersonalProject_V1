package com.enr_operational.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.Driver;
import com.enroperation.identifiers.TradeRelationshipTabPageIdentifier;

public class CreateAccountInboundTradeRelationshipPage {

	public CreateAccountInboundTradeRelationshipPage() {
		PageFactory.initElements(Driver.getDriver(), this);
	}

//	@FindBy(xpath = TradeRelationshipTabPageIdentifier.)
//	public WebElement;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.tradeRelationSHipTabXpath)
	public WebElement tradeRelationshipsButton;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.addTrButtonXpath)
	public WebElement AddTrButton;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.addNoteButton)
	public WebElement addNoteButton;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.closeButtonXpath)
	public WebElement closeButton;

	@FindBy(id = TradeRelationshipTabPageIdentifier.addTradeRelationshipPopup)
	public WebElement addTradeRelationshipPopup;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.relationshipTypeRadioButton)
	public WebElement relationshipTypeRadioButton;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.thirdPartyAgentInputXpath)
	public WebElement thirdPartyAgentInput;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.agentTradeRelationshipAgreementXpath)
	public WebElement agentTradeRelationshipAgreement;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.maintenanceTypeXpath)
	public WebElement maintenanceType;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.tradingTypeXpath)
	public WebElement tradingType;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.tradeRelationshipAgreementXpath)
	public WebElement tradeRelationshipAgreement;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.nextBtnXpath)
	public WebElement nextBtn;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.modeXPath)
	public WebElement mode;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.formatButtonXPath)
	public WebElement formatButton;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.tradeRelationshipFormatXpath)
	public WebElement tradeRelationshipFormat;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.ISA06senderIdXpath)
	public WebElement ISA06senderId;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.GSsenderIdXpath)
	public WebElement GSsenderId;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.SaveTradeButtonXpath)
	public WebElement SaveTradeButton;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.format834Xpath)
	public WebElement format834;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.senderIdXpath)
	public WebElement senderId;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.receiverIdXpath)
	public WebElement receiverId;

	@FindBy(id = TradeRelationshipTabPageIdentifier.tradeRelationshipNameId)
	public WebElement tradeRelationshipName;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.agentTradeRelationshipAgreemtnXpath)
	public WebElement agentTradeRelationshipAgreemtn;

	@FindBy(xpath = TradeRelationshipTabPageIdentifier.senderIdValueXpath)
	public WebElement senderIdValue;

	@FindBy(xpath = "//span[text()='Account Identifier Location']/parent::label/following-sibling::div/div/div[2]")
	public WebElement accountIndetLocation;

	@FindBy(xpath = "//input[@id='scheduleComboId-inputEl']")
	public WebElement schedulerInput;

	@FindBy(xpath = "//input[@id='dayComboId-inputEl']")
	public WebElement dayScedulerInput;

	public void schedulRotation(String type) {
		System.out.println("Frequency: "+type);
		schedulerInput.click();
		BrowserUtils.waitFor(2);
		Driver.getDriver().findElement(By.xpath("//li[text()='"+type+"']")).click();
		
	}
	
	public void scheduleDay(String value) {
		System.out.println("Daily Scheduler: "+value);
		dayScedulerInput.click();
		BrowserUtils.waitFor(2);
		if(value.equals("Week days") ) {
			Driver.getDriver().findElement(By.xpath("//li[text()='Week Days']")).click();
		}else if(value.equals("Every day")){
			Driver.getDriver().findElement(By.xpath("//li[text()='Every Day']")).click();
		}else {
			Driver.getDriver().findElement(By.xpath("//li[text()='"+value+"']")).click();
		}
		
	}
	
	

	public WebElement getTradeOptions(String name) throws InterruptedException {
		for (int i = 0; i < 20; i++) {
			try {
				// return Driver.getDriver().findElement(By.xpath("//li[text()='" + name +
				// "']"));
				if (Driver.getDriver().findElement(By.xpath("//li[text()='" + name + "']")) != null) {
					return Driver.getDriver().findElement(By.xpath("//li[text()='" + name + "']"));
				} else {
					Thread.sleep(1000);
					System.out.println("<--> Else");
				}

			} catch (Exception e) {
				System.out.println("StaleElementReferenceException is handled");
				Thread.sleep(1000);
			}
		}
		throw new InterruptedException("Element not found with in 20 seconds");
	}

}
