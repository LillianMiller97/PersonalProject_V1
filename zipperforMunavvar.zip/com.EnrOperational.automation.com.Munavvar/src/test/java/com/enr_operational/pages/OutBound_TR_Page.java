package com.enr_operational.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.enr_operational.utilities.Driver;
import com.enroperation.identifiers.OutBound_TR_PageIdentifier;

public class OutBound_TR_Page {
	public OutBound_TR_Page() {
		PageFactory.initElements(Driver.getDriver(), this);
	}

	@FindBy(id = OutBound_TR_PageIdentifier.partnerIconID)
	public WebElement partnersTab;

	@FindBy(id = OutBound_TR_PageIdentifier.partnerNameID)
	public WebElement partnerName;

	@FindBy(id = OutBound_TR_PageIdentifier.partnerSearchButtonID)
	public WebElement partnerSearchButton;

	@FindBy(xpath = OutBound_TR_PageIdentifier.partnersRelationshipTabXpath)
	public WebElement partnersRelationshipTab;

	@FindBy(id = OutBound_TR_PageIdentifier.pertnerAddTradeRelButtonID)
	public WebElement pertnerAddTradeRelButton;

	@FindBy(xpath = OutBound_TR_PageIdentifier.partnersNextButtonXpath)
	public WebElement partnersNextButton;

	@FindBy(id = OutBound_TR_PageIdentifier.partnersCancelButtonID)
	public WebElement partnersCancelButton;

	@FindBy(xpath = OutBound_TR_PageIdentifier.roleReceiverXpath)
	public WebElement roleReceiver;

	@FindBy(xpath = OutBound_TR_PageIdentifier.roleSenderXpath)
	public WebElement roleSender;

	@FindBy(id = OutBound_TR_PageIdentifier.roleRelatedPartnerID)
	public WebElement roleRelatedPartner;

	@FindBy(id = OutBound_TR_PageIdentifier.WizardTradeRelNameID)
	public WebElement WizardTradeRelName;

	@FindBy(id = OutBound_TR_PageIdentifier.finishBtnID)
	public WebElement finishBtn;

	@FindBy(xpath = OutBound_TR_PageIdentifier.outboundResTextXpath)
	public WebElement outboundResText;

	public WebElement getFirstAccountByName(String name) throws Exception {
		for (int i = 0; i < 20; i++) {
			try {
				return Driver.getDriver().findElement(By.xpath("(//a[text()='" + name + "'])[1]"));
			} catch (Exception e) {
				System.out.println("Exception handled");
			}
		}
		throw new Exception("Couldn't find account by name:  " + name);
	}

	public void selectBUsinessDocumentByName(String name) {
		Select dropdown = new Select(Driver.getDriver().findElement(By.id("Business Document")));
		dropdown.selectByVisibleText(name);
	}

	public void selectInterchangeReceiverIDByIndex(int index) {
		Select dropdown = new Select(Driver.getDriver().findElement(
				By.xpath("//div[text()='InterchangeReceiverID: ']/parent::td/following-sibling::td/select")));
		dropdown.selectByIndex(index);
	}

	public void selectInterchangeSenderIDByName(String name) {
		Select dropdown = new Select(Driver.getDriver().findElement(
				By.xpath("//div[text()='InterchangeSenderID: ']/parent::td/following-sibling::td/select")));
		dropdown.selectByVisibleText(name);
	}

	public boolean isRelExist(String name) {
		try {
			String caseName = Driver.getDriver().findElement(By.xpath("//div[text()='" + name + "']")).getText();
			if (caseName.equals(name)) {
				return true;
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

}
