package com.enr_operational.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.Driver;
import com.enroperation.identifiers.CreateAccountTabPageIdentifier;

public class CreateAccountsTabAndPage {

	public CreateAccountsTabAndPage() {
		PageFactory.initElements(Driver.getDriver(), this);
	}

	@FindBy(xpath = CreateAccountTabPageIdentifier.creatAccountButtonIdentifierXpath)
	public WebElement createAccountButton;

	@FindBy(xpath = CreateAccountTabPageIdentifier.AccountsTabIdentifierXpath)
	public WebElement accountsTab;

	@FindBy(xpath = CreateAccountTabPageIdentifier.ShortNameIdentifierXpath)
	public WebElement ShortName;

	@FindBy(xpath = CreateAccountTabPageIdentifier.validationButtonIdentifierXpath)
	public WebElement validationBtn;

	@FindBy(xpath = CreateAccountTabPageIdentifier.nameIdentifierXpath)
	public WebElement name;

	@FindBy(xpath = CreateAccountTabPageIdentifier.addressIdentifierXpath)
	public WebElement address;

	@FindBy(xpath = CreateAccountTabPageIdentifier.cityIdentifierXpath)
	public WebElement city;

	@FindBy(xpath = CreateAccountTabPageIdentifier.zipCodeIdentifier)
	public WebElement zipCode;

	@FindBy(xpath = CreateAccountTabPageIdentifier.AccountIdentifierInputXpath)
	public WebElement accountIdentifierInput;

	@FindBy(xpath = CreateAccountTabPageIdentifier.saveLinkIdentifierXpath)
	public WebElement SaveButton;

	@FindBy(xpath = CreateAccountTabPageIdentifier.AlertAcceptButtonXpath)
	public WebElement alertAccept;

	@FindBy(xpath = CreateAccountTabPageIdentifier.organizationTypeArrowXpath)
	public WebElement organizationTypeArrow;

	@FindBy(xpath = CreateAccountTabPageIdentifier.parentAccountInputXpath)
	public WebElement parentAccountInput;

	@FindBy(xpath = CreateAccountTabPageIdentifier.inputTextForOrganizationTypeXPath)
	public WebElement inputTextForOrganizationType;

	@FindBy(xpath = CreateAccountTabPageIdentifier.organizationTypeInputXpath)
	public List<WebElement> organizationTypeInput;

	@FindBy(xpath = CreateAccountTabPageIdentifier.parentAccountPickerXpath)
	public WebElement parentAccountPicker;
	
	@FindBy(xpath=CreateAccountTabPageIdentifier.roleArrowXpath)
	public WebElement roleArrow;
	
	@FindBy(xpath = "//font[text()='Other Identifier']")
	public WebElement otherIdentifierLink;
	
	@FindBy(xpath = "//input[contains(@name,'IdentifierType')]")
	public List<WebElement> identifierLabelIntputList;
	
	@FindBy(xpath = "//input[contains(@name,'IdentifierValue')]")
	public List<WebElement> identifierValueIntputList;
	
	
	
	

	public void chooseOptions(String option) {
		Driver.getDriver().findElement(By.xpath("(//*[contains(@id,'trigger-picker')])[4]")).click();
		try {
			Thread.sleep(2345);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		new Actions(Driver.getDriver())
				.moveToElement(Driver.getDriver().findElement(By.xpath("//li[.='" + option + "']"))).click().build()
				.perform();
	}

	public WebElement getParrentAccountOption(String name) {
		return Driver.getDriver().findElement(By.xpath("//li[text()='" + name + "']"));
	}
	
	public void getOption(String name) {
		try {
			BrowserUtils.waitFor(2);
			new Actions(Driver.getDriver())
			.moveToElement(Driver.getDriver().findElement(By.xpath("//li[.='" + name + "']"))).click().build()
			.perform();
		}catch(Exception e) {
			System.out.println("Option: "+name+" is not found");
			System.out.println("Removing formula for Employer Group");
			try {
				String[] eGroupArr = name.split("\"");
				String eGroupArrNoFormula = eGroupArr[eGroupArr.length-2];
				new Actions(Driver.getDriver())
				.moveToElement(Driver.getDriver().findElement(By.xpath("//li[.='" + eGroupArrNoFormula + "']"))).click().build()
				.perform();
				
			}catch(Exception a) {
				System.out.println("Option: is not found");
			}
		}
		
	}
	

}
