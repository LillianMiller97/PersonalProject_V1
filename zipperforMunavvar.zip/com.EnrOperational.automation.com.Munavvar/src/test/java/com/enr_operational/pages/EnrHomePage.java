package com.enr_operational.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.enr_operational.utilities.Driver;
import com.enroperation.identifiers.EnrHomePageIdentifier;

public class EnrHomePage {

	public EnrHomePage() {
		PageFactory.initElements(Driver.getDriver(), this);
	}

	@FindBy(xpath = EnrHomePageIdentifier.enrHomePageTitleIdentifierID)
	public WebElement homePageTitle;

	@FindBy(xpath = EnrHomePageIdentifier.enrTransactionTabIdentifierXpath)
	public WebElement transactionTab;

	@FindBy(xpath = EnrHomePageIdentifier.enr_EnrTransactionsTabIdentifierXpath)
	public WebElement enrTransactionsTab;

	@FindBy(xpath = EnrHomePageIdentifier.enr_EnrollmentDashboardsTabIdentifierXpath)
	public WebElement enrollmentDashboardsTab;

	@FindBy(xpath = EnrHomePageIdentifier.enrMembersTabIdentifierXpath)
	public WebElement membersTab;

	@FindBy(xpath = EnrHomePageIdentifier.enrWorkflowTabIdentifierXpath)
	public WebElement workflowTab;

	@FindBy(xpath = EnrHomePageIdentifier.allAccountsXpath)
	public WebElement allAccounts;

	@FindBy(xpath = EnrHomePageIdentifier.assignedToMeLinkXpath)
	public WebElement assignedToMeLink;

	@FindBy(xpath = EnrHomePageIdentifier.portalAccessXpath)
	public WebElement portalAccess;

	@FindBy(xpath = EnrHomePageIdentifier.searchKeyXpath)
	public WebElement searchKey;

	@FindBy(xpath = EnrHomePageIdentifier.searchKeyInputXpath)
	public WebElement searchKeyInput;

	@FindBy(xpath = EnrHomePageIdentifier.searchIconXpath)
	public WebElement searchIcon;
	
	@FindBy(xpath = "//input[contains(@id,'textfield')]")
	public WebElement searchField;

}
