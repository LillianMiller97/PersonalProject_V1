package com.enr_operational.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.enr_operational.utilities.Driver;
import com.enroperation.identifiers.AccountDetailPageIdentifier;

public class AccountDetailPage {

	public AccountDetailPage() {
		PageFactory.initElements(Driver.getDriver(), this);
	}

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailHeaderId)
	public WebElement accountDetailHeader;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailGeneralTabXpath)
	public WebElement accountDetailGeneralTab;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailContactTabXpath)
	public WebElement accountDetailContactTab;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailTradeRelationshipsTabXpath)
	public WebElement accountDetailTradeRelationshipsTab;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailTasksTabXpath)
	public  WebElement accountDetailTasksTab;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailNotesTabXpath)
	public  WebElement accountDetailNotesTab;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailTransmissionsTabXpath)
	public  WebElement accountDetailTransmissionsTab;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailPolicyUnitsTabXpath)
	public  WebElement accountDetailPolicyUnitsTab;

	@FindBy(xpath = AccountDetailPageIdentifier.accountDetailHistoryTabXpath)
	public  WebElement accountDetailHistoryTab;
	
	@FindBy(xpath=AccountDetailPageIdentifier.firstAccountOnListXpath)
	public  WebElement firstAccount;

	@FindBy(xpath=AccountDetailPageIdentifier.accountViewBodyID)
	public  WebElement accountViewBody;
	
	@FindBy(xpath="(//a[contains(@href,'tradeRelationship')])[2]")
	public WebElement tradeRelationship;
	
	public WebElement getTRByName(String name) {
		return Driver.getDriver().findElement(By.xpath("//a[text()='"+name+"']"));
	}

	
	
	
	
	
	
	

}
