package com.enr_operational.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.enr_operational.utilities.Driver;
import com.enroperation.identifiers.CreateAccount_InternalContactPageIdentifier;

public class CreateAccount_InternalContactPage {

	public CreateAccount_InternalContactPage() {
		PageFactory.initElements(Driver.getDriver(), this);
	}
	
	@FindBy(xpath = CreateAccount_InternalContactPageIdentifier.assignIntContactBtnIdentifierXpath)
    public WebElement assignContactLink;
	
	@FindBy(xpath = CreateAccount_InternalContactPageIdentifier.internalContactArrowTrigerXpath)
	public WebElement internalContactArrowTriger;
	
	@FindBy(name = CreateAccount_InternalContactPageIdentifier.roleInputName)
	public WebElement roleInput;
	
	@FindBy(xpath = CreateAccount_InternalContactPageIdentifier.rptSubMaintenanceSummaryCheckBoxXpath)
	public WebElement rptSubMaintenanceSummaryCheckBox;
	
	@FindBy(xpath = CreateAccount_InternalContactPageIdentifier.rptSubMaintenanceDetailCheckBoxXpath)
	public WebElement rptSubMaintenanceDetailCheckBox;
	
	@FindBy(xpath = CreateAccount_InternalContactPageIdentifier.rptSubAuditSummaryCheckBoxXpath)
	public WebElement rptSubAuditSummaryCheckBox;
	
	@FindBy(xpath = CreateAccount_InternalContactPageIdentifier.rptSubAuditDetailCheckBoxXpath)
	public WebElement rptSubAuditDetailCheckBox;
	
	@FindBy(xpath = CreateAccount_InternalContactPageIdentifier.rptSubComplianceResultCheckBoxXpath)
	public WebElement rptSubComplianceResultCheckBox;
	
	@FindBy(xpath =  CreateAccount_InternalContactPageIdentifier.saveIntContBtnXpath)
	public WebElement saveIntContBtn;
	
	@FindBy(name = "TPMContactSID")
	public WebElement searchInput;
	
	@FindBy(xpath = "//span[text()='Email']/parent::label/following-sibling::div/div/a")
	public WebElement email;
	
	@FindBy(name = "BusinessTelephoneNumber")
	public WebElement phone;
	
	public WebElement getContactByName(String contactName) {
	    return Driver.getDriver().findElement(By.xpath("//div[text()='"+contactName+"']/parent::li"));
	}
	
	public WebElement getRoleByName(String roleName) {
		return Driver.getDriver().findElement(By.xpath("//li[text()='"+roleName+"']"));
	}
	
	public WebElement getReportSubscription(int mapIndex) {
		switch(mapIndex) {
		case 1:
			return this.rptSubMaintenanceSummaryCheckBox;
		case 2:
			return  this.rptSubMaintenanceDetailCheckBox;
		case 3:
			return this.rptSubAuditSummaryCheckBox;
		case 4: 
			return this.rptSubAuditDetailCheckBox;
		case 5: 
			return this.rptSubComplianceResultCheckBox;
		default:
			return null;
		}
	}
	
	
	
	

}
