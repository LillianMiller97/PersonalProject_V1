package com.enr_operational.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ContactBean;
import com.enr_operational.utilities.Driver;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.ReportSubscriptionType;

public class Create_Third_Party_Agent_Account_Assign_Internal_Contact_Test extends TestBase {

	@Test
	public void create_Third_Party_Agent_Account_Assign_Internal_Contact_Test() throws Exception {
//		extentLogger = report.createTest("create Third Party Agent Account and _Assign_Internal_Contact test");
//		// info () --> to print a message
//		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");

		int num = BrowserUtils.getRundomNumInRange(999, 1999);
		int acIdentifierNum = BrowserUtils.getRundomNumInRange(1000000, 9000000);
		String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.waitForPageToLoad(2);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
		Thread.sleep(2000);
		String shortName = "Test_Automation_" + num + "";
		pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
		pages.getCreateAccountsTabAndPage().validationBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
		String name = "New_Test_Account";
		pages.getCreateAccountsTabAndPage().name.sendKeys(name);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);
		
		butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
		pages.getCreateAccountsTabAndPage().organizationTypeInput.get(2).click();
		
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
		String accountIdentifier = "00-" + einNumber;
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
		BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
		pages.getCreateAccountsTabAndPage().SaveButton.click();
		System.out.println(num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);

		// Write to Excel
		String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Account");

		AccountBean account = new AccountBean();
		account.setActionFlag("C");
		account.setShortName(shortName);
		account.setName(name);
		account.setOrganizationType("Third Party Agent");
		account.setAccountIdentifierValue(accountIdentifier);
		account.setExecutionStatus("pass");
		excelUtils.writeAccountToExcel(account);

		pages.getAccountDetailPage().accountDetailContactTab.click();
		for (int i = 0; i <= 2; i++) {

			pages.getCreateAccounts_InternalContactPage().assignContactLink.click();
			String[] contNames = { "Ezhilarasan Rajendran", "Aurea Shelton", "Sabrina Scanlon" };
			pages.getCreateAccounts_InternalContactPage().searchInput.sendKeys(contNames[i]);
			butil.waitFor(6);
			Actions action = new Actions(Driver.getDriver());
			action.sendKeys(Keys.ENTER).build().perform();

			String email = pages.getCreateAccounts_InternalContactPage().email.getText();
			String phone = pages.getCreateAccounts_InternalContactPage().phone.getAttribute("value");
			String role = "System Administrator";

			pages.getCreateAccounts_InternalContactPage().roleInput.sendKeys(role);
			butil.waitFor(5);
			action = new Actions(Driver.getDriver());
			action.sendKeys(Keys.ENTER).build().perform();

			pages.getCreateAccounts_InternalContactPage().rptSubMaintenanceSummaryCheckBox.click();
			pages.getCreateAccounts_InternalContactPage().rptSubAuditSummaryCheckBox.click();
			pages.getCreateAccounts_InternalContactPage().saveIntContBtn.click();

			excelUtils = new ExcelUtils(path, "Account");

			ContactBean contact = new ContactBean();
			String contName = contNames[i];
			contact.setFirstName(contName.split(" ")[0]);
			contact.setLastName(contName.split(" ")[1]);
			contact.setEmail(email);
			contact.setPhone(phone);
			contact.setTitle(role);
			contact.setReportSubscription(ReportSubscriptionType.AUDIT_SUMMARY, ReportSubscriptionType.MAINTENANCE);
			excelUtils.writeContactToAccount(shortName, contact);
		}

	}
}
