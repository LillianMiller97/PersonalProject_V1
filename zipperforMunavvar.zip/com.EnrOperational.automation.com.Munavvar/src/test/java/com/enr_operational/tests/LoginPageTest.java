package com.enr_operational.tests;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.enr_operational.pages.LoginPage;
import com.enr_operational.utilities.Driver;

public class LoginPageTest extends TestBase {

	@Test
	public void loginApplication() throws Exception {
		LoginPage loginPage = new LoginPage();

		extentLogger = report.createTest("Positive login test");
		// info () --> to print a message
		extentLogger.info("entering user credentials");
		loginPage.loginApplication();

		System.out.println(Driver.getDriver().getTitle());
		extentLogger.info("click login");

		extentLogger.info("Verifying log out link");

		// pass --> message the tells us what passed
		extentLogger.pass("Verified log out link displayed");

	}

	public boolean VerifyLogin(String name, WebElement element) {

		return element.getAttribute("value").equals(name);
	}

	@Test
	public void loginApplication2() throws Exception {

		LoginPage loginPage = new LoginPage();

		extentLogger = report.createTest("Negative login test");
		// info () --> to print a message
		extentLogger.info("entering bad user credentials");
		loginPage.loginApplication();

		System.out.println(Driver.getDriver().getTitle());
		extentLogger.info("click login");

		extentLogger.info("Verifying log out link not diplayed");

	
		// pass --> message the tells us what passed
		extentLogger.pass("Verified log out link displayed");

	}

}
