package com.enr_operational.tests;

import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.MasterTableBean;

public class Creat_Self_Account_Test extends TestBase {

	@Test
	public void creat_Self_Account_Test() throws Exception {
		
//		extentLogger = report.createTest("create Self Account test");
//		// info () --> to print a message
//		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");

		int num = BrowserUtils.getRundomNumInRange(999, 1999);
		int acIdentifierNum = BrowserUtils.getRundomNumInRange(1000000, 9000000);
		String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.waitForPageToLoad(2);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
		Thread.sleep(2000);
		String shortName = "Automation"+num;
		pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
		pages.getCreateAccountsTabAndPage().validationBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
		String name = "New_Test_Account";
		pages.getCreateAccountsTabAndPage().name.sendKeys(name);
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
		String accountIdentifier = "00-" + einNumber;
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
		BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
		pages.getCreateAccountsTabAndPage().SaveButton.click();
		System.out.println(num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);

		// Write to Excel
		String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Account");

		AccountBean account = new AccountBean();
		account.setActionFlag("C");
		account.setShortName(shortName);
		account.setName(name);
		account.setOrganizationType("Account");
		account.setAccountIdentifierValue(accountIdentifier);
		account.setExecutionStatus("pass");
		excelUtils.writeAccountToExcel(account);

		excelUtils = new ExcelUtils(path, "Master Table");
		MasterTableBean masterTable = new MasterTableBean();
		masterTable.setExistingAccountName(account.getShortName());
		masterTable.setOrganizationType(account.getOrganizationType());
		excelUtils.writeDataToMasterTable(masterTable);

	}
}
