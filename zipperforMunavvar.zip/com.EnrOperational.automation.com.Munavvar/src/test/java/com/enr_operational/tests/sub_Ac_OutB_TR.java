package com.enr_operational.tests;

import java.util.Random;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.Driver;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class sub_Ac_OutB_TR extends TestBase {

	String path = "ENR_Operational_Excel_Updated_1212.xlsx";

	@Test
	public void create_Self_Account_Create_OutBound_TradeRelationship_Test() throws Exception {
		Random random = new Random();
		String accountName = create_Sub_Account();
		String outboundRelName = "BCBSMA_Confirm";

		extentLogger = report.createTest("Create OutBound Trade Relationsship Test");
		// info () --> to print a message
		extentLogger.info("entering user credentials");
		int low = 999;
		int high = 1999;
		int num = random.nextInt(high - low) + low;
		int acIdentifierNum = random.nextInt(10000000);
		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersTab);
		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnerName);
		pages.getOutBound_TR_Page().partnerName.sendKeys(accountName);
		pages.getOutBound_TR_Page().partnerSearchButton.click();
		pages.getOutBound_TR_Page().getFirstAccountByName(accountName).click();
		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersRelationshipTab);
		Driver.getDriver().switchTo().frame("relationshipsFrame");
		Thread.sleep(1000);
		pages.getOutBound_TR_Page().pertnerAddTradeRelButton.click();
		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersNextButton);
		Thread.sleep(2000);
		pages.getOutBound_TR_Page().roleReceiver.click();
		String actualRelatedPartner = pages.getOutBound_TR_Page().roleRelatedPartner.getAttribute("value").trim();
		Assert.assertEquals(actualRelatedPartner, "Blue Cross Blue Shield of MA");

		pages.getOutBound_TR_Page().partnersNextButton.click();

		pages.getOutBound_TR_Page().WizardTradeRelName.sendKeys(outboundRelName);
		pages.getOutBound_TR_Page().selectBUsinessDocumentByName("Enrollment Response File");
		pages.getOutBound_TR_Page().partnersNextButton.click();
		sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
		pages.getOutBound_TR_Page().partnersNextButton.click();
		sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
		pages.getOutBound_TR_Page().partnersNextButton.click();
		Thread.sleep(2000);
		pages.getOutBound_TR_Page().selectInterchangeReceiverIDByIndex(1);
		pages.getOutBound_TR_Page().selectInterchangeSenderIDByName("041045815 - ISA Identifier");
		sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
		pages.getOutBound_TR_Page().partnersNextButton.click();
		pages.getOutBound_TR_Page().finishBtn.click();
		Driver.getDriver().switchTo().frame("relationshipsFrame");
		boolean isRelExist = pages.getOutBound_TR_Page().isRelExist(outboundRelName);
		Assert.assertTrue(isRelExist);
		String actualOutboundResText = pages.getOutBound_TR_Page().outboundResText.getText();
		Assert.assertEquals(actualOutboundResText, "Outbound");

		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");
		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		trBean.setActionFlag("C");
		trBean.settRType("Outbound");
		trBean.setAccountShortName(accountName);
		trBean.setOutBoundTRName(actualOutboundResText);
		trBean.setMode("Un-Monitored");
		trBean.setSenderId(String.valueOf(536));
		trBean.setOutboundStatus("pass");
		trBean.setDivisionList("Un-Monitored");
		excelUtils.writeTradeRelationshipData(trBean);
	}

	private String create_Sub_Account() throws Exception {
		Random random = new Random();
		extentLogger = report.createTest("create Sub-Account Test");

		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		int low = 999;
		int high = 1999;
		int num = random.nextInt(high - low) + low;
		int acIdentifierNum = random.nextInt(10000000);
		String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.waitForPageToLoad(2);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
		Thread.sleep(2000);
		String shortName = "TestTest" + num + "";
		pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
		pages.getCreateAccountsTabAndPage().validationBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);

		String accountName = "TradeRelAccount" + num;
		pages.getCreateAccountsTabAndPage().name.sendKeys(accountName);

		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);

		try {
			Thread.sleep(2000);
		} catch (Exception e) {

		}

		butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
		pages.getCreateAccountsTabAndPage().organizationTypeInput.get(1).click();
		pages.getCreateAccountsTabAndPage().parentAccountPicker.click();
		String parentAccount = "E2E_ENR_Release2_ vietnam";
		butil.waitForClickablility(By.xpath("//li[text()='" + parentAccount + "']"), 20);
		pages.getCreateAccountsTabAndPage().getParrentAccountOption(parentAccount).click();

		pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys("00-" + acIdentifierNum);
		BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
		pages.getCreateAccountsTabAndPage().SaveButton.click();
		System.out.println(num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);

		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
		pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Changes Only").click();
		pages.getCreateAccountTradeRelationshipPage().tradingType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Self").click();
		pages.getCreateAccountTradeRelationshipPage().tradeRelationshipAgreement.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("BCBSMA_DirectAccountDefaultsChangesOnly")
				.click();
		pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
		sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);

		String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
				.getAttribute("value");

		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
		String accountIdentifier = "00-" + einNumber;
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().ISA06senderId);
		pages.getCreateAccountTradeRelationshipPage().ISA06senderId.sendKeys("" + num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().GSsenderId);
		pages.getCreateAccountTradeRelationshipPage().GSsenderId.sendKeys("" + num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
		butil.waitForPageToLoad(1000);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
		butil.waitForPageToLoad(2000);

		ExcelUtils excelUtils = new ExcelUtils(path, "Account");

		AccountBean account = new AccountBean();
		account.setActionFlag("C");
		account.setShortName(shortName);
		account.setName(accountName);
		account.setOrganizationType("Account");
		account.setAccountIdentifierValue(accountIdentifier);
		account.setExecutionStatus("pass");
		excelUtils.writeAccountToExcel(account);

		excelUtils = new ExcelUtils(path, "Trade Relationship");

		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		trBean.setActionFlag("C");
		trBean.settRType("Inbound");
		trBean.setAccountShortName(account.getShortName());
		trBean.setInBoundTRName(tradeRelationshipName);
		trBean.settRCategory("Change File By Self Submitter");
		trBean.setMode("Un-Monitored");
		trBean.setSenderId(String.valueOf(num));
		trBean.setInboundStatus("pass");
		trBean.setDivisionList("Un-Monitored");
		excelUtils.writeTradeRelationshipData(trBean);

		return accountName;

	}

}
