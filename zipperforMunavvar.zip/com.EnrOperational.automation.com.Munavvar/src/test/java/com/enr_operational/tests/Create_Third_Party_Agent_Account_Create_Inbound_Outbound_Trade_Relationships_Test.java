package com.enr_operational.tests;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.Driver;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.MasterTableBean;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class Create_Third_Party_Agent_Account_Create_Inbound_Outbound_Trade_Relationships_Test extends TestBase {

	String path = "ENR_Operational_Excel_Updated_1212.xlsx";

	@Test
	public void create_Self_Account_Create_Inbound_Outbound_Trade_Relationships_Test() throws Exception {
		AccountBean account = createAccount();
		String accountName = account.getName();
		String outboundRelName = "BCBSMA_Confirm";

//		extentLogger = report.createTest("create Self Account and  Create Inbound & OutBound Trade Relationship Test");
//		// info () --> to print a message
//		extentLogger.info("entering user credentials");

		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersTab);
		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnerName);
		pages.getOutBound_TR_Page().partnerName.sendKeys(accountName);
		pages.getOutBound_TR_Page().partnerSearchButton.click();
		pages.getOutBound_TR_Page().getFirstAccountByName(accountName).click();
		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersRelationshipTab);
		Driver.getDriver().switchTo().frame("relationshipsFrame");
		Thread.sleep(1000);
		pages.getOutBound_TR_Page().pertnerAddTradeRelButton.click();
		butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersNextButton);
		Thread.sleep(2000);
		pages.getOutBound_TR_Page().roleReceiver.click();
		String actualRelatedPartner = pages.getOutBound_TR_Page().roleRelatedPartner.getAttribute("value").trim();
		Assert.assertEquals(actualRelatedPartner, "Blue Cross Blue Shield of MA");

		pages.getOutBound_TR_Page().partnersNextButton.click();

		pages.getOutBound_TR_Page().WizardTradeRelName.sendKeys(outboundRelName);
		pages.getOutBound_TR_Page().selectBUsinessDocumentByName("Enrollment Response File");
		pages.getOutBound_TR_Page().partnersNextButton.click();
		sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
		pages.getOutBound_TR_Page().partnersNextButton.click();
		sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
		pages.getOutBound_TR_Page().partnersNextButton.click();
		Thread.sleep(2000);
		pages.getOutBound_TR_Page().selectInterchangeReceiverIDByIndex(1);
		pages.getOutBound_TR_Page().selectInterchangeSenderIDByName("041045815 - ISA Identifier");
		sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
		pages.getOutBound_TR_Page().partnersNextButton.click();
		pages.getOutBound_TR_Page().finishBtn.click();
		Driver.getDriver().switchTo().frame("relationshipsFrame");
		boolean isRelExist = pages.getOutBound_TR_Page().isRelExist(outboundRelName);
		Assert.assertTrue(isRelExist);
		String actualOutboundResText = pages.getOutBound_TR_Page().outboundResText.getText();
		Assert.assertEquals(actualOutboundResText, "Outbound");

		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");
		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		trBean.setActionFlag("C");
		trBean.settRType("Outbound");
		trBean.setAccountShortName(account.getShortName());
		trBean.setOutBoundTRName(outboundRelName);
		trBean.setMode("Un-Monitored");
		trBean.setSenderId(String.valueOf(536));
		trBean.setOutboundStatus("pass");
		trBean.setDivisionList("Un-Monitored");
		excelUtils.writeTradeRelationshipData(trBean);

		excelUtils = new ExcelUtils(path, "Master Table");
		MasterTableBean masterTable = new MasterTableBean();
		masterTable.setExistingAccountName(accountName);
		masterTable.setOrganizationType(account.getOrganizationType());
		masterTable.settRName(trBean.getOutBoundTRName());
		masterTable.setTypeOfTR(trBean.gettRType());
		excelUtils.writeDataToMasterTable(masterTable);
	}

	private AccountBean createAccount() throws Exception {
//		extentLogger = report.createTest("create Account Test");
//		extentLogger.info("entering user credentials");

		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		int num = BrowserUtils.getRundomNumInRange(999, 1999);
		int acIdentifierNum = BrowserUtils.getRundomNumInRange(1000000, 9000000);
		String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.waitForPageToLoad(2);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
		Thread.sleep(2000);
		String shortName = "Test_Automation_" + num + "";
		pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
		pages.getCreateAccountsTabAndPage().validationBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
		String accountName = "New_Test_Account" + num;
		pages.getCreateAccountsTabAndPage().name.sendKeys(accountName);

		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);
		butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
		pages.getCreateAccountsTabAndPage().organizationTypeInput.get(2).click();
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();

		String accountIdentifier = "00-" + einNumber;
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
		BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
		pages.getCreateAccountsTabAndPage().SaveButton.click();
		System.out.println(num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);

//Adding Trade Relationship		
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
		pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Changes Only").click();
		pages.getCreateAccountTradeRelationshipPage().tradingType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Self").click();
		pages.getCreateAccountTradeRelationshipPage().tradeRelationshipAgreement.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("BCBSMA_DirectAccountDefaultsChangesOnly")
				.click();
		pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
		sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);

		String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
				.getAttribute("value");

		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().ISA06senderId);

		pages.getCreateAccountTradeRelationshipPage().ISA06senderId.sendKeys("" + num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().GSsenderId);
		pages.getCreateAccountTradeRelationshipPage().GSsenderId.sendKeys("" + num);
		
		pages.getCreateAccountTradeRelationshipPage().accountIndetLocation.click();
		String accountIdentifierLoc = "1000A\\N1[04]";
		butil.waitForClickablility(pages.getCreateAccountTradeRelationshipPage().getTradeOptions(accountIdentifierLoc), 5);
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions(accountIdentifierLoc).click();
		
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
		butil.waitForPageToLoad(1000);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
		butil.waitForPageToLoad(2000);

		// ac identifier
		ExcelUtils excelUtils = new ExcelUtils(path, "Account");

		AccountBean account = new AccountBean();
		account.setActionFlag("C");
		account.setShortName(shortName);
		account.setName(accountName);
		account.setOrganizationType("Account");
		account.setAccountIdentifierValue(accountIdentifier);
		account.setExecutionStatus("pass");
		excelUtils.writeAccountToExcel(account);

		excelUtils = new ExcelUtils(path, "Trade Relationship");

		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		trBean.setActionFlag("C");
		trBean.settRType("Inbound");
		trBean.setAccountShortName(account.getShortName());
		trBean.setInBoundTRName(tradeRelationshipName);
		trBean.settRCategory("Change File By Self Submitter");
		trBean.setMode("Un-Monitored");
		trBean.setSenderId(String.valueOf(num));
		trBean.setInboundStatus("pass");
		trBean.setDivisionList("Un-Monitored");
		trBean.setAccountIdentifierLocation(accountIdentifierLoc);
		excelUtils.writeTradeRelationshipData(trBean);

		excelUtils = new ExcelUtils(path, "Master Table");
		MasterTableBean masterTable = new MasterTableBean();
		masterTable.setExistingAccountName(account.getShortName());
		masterTable.setOrganizationType(account.getOrganizationType());
		masterTable.settRName(trBean.getInBoundTRName());
		masterTable.setTypeOfTR(trBean.gettRType());
		excelUtils.writeDataToMasterTable(masterTable);

		return account;
	}
}