package com.enr_operational.tests;

import org.testng.annotations.Test;

import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class Third_Party_Agent_Changes_Only_Trade_Relationship_For_First_Self_Account_Test extends TestBase {

	@Test
	public void loginAndCreateThird_Party_Agent_Changes_Only_Trade_Relationship_For_First_Self_Account_Test() throws Exception {
   
	 	extentLogger = report.createTest("login and Create Third Party Agent Changes Only Trade Relationship For First Self Account");
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
		String accountShortName = pages.getAccountDetailPage().firstAccount.getText();
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
		butil.waitForPageToLoad(2000);
			
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
		pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Changes Only").click();
		pages.getCreateAccountTradeRelationshipPage().tradingType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Third Party Agent").click();
		pages.getCreateAccountTradeRelationshipPage().tradeRelationshipFormat.click();
		pages.getCreateAccountTradeRelationshipPage().format834.click();
		pages.getCreateAccountTradeRelationshipPage().thirdPartyAgentInput.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("ADP").click();
		pages.getCreateAccountTradeRelationshipPage().agentTradeRelationshipAgreement.click();
		String agentTradeRel = "ADP_Maintenance_Changes_04/16/2018_1";
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions(agentTradeRel).click();
		pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
		sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
		
		String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
				.getAttribute("value");
		
		butil.waitForVisibility(pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored"), 5);
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
		String senderId = pages.getCreateAccountTradeRelationshipPage().senderIdValue.getText();
			
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
		
		String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");
		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		
		trBean.setActionFlag("C");
		trBean.settRType("Inbound");
		trBean.setAccountShortName(accountShortName);
		trBean.setInBoundTRName(tradeRelationshipName);
		trBean.settRCategory("Change File By Self Submitter");
		trBean.setThirdPartyAgent("ADP");
		trBean.setAgentTradeRelationship(agentTradeRel);
		trBean.setMode("Un-Monitored");
		trBean.setSenderId(senderId);
		trBean.setDivisionList("--N/A for Change File");
		trBean.setInboundStatus("pass");
		excelUtils.writeTradeRelationshipData(trBean);
	}
}
