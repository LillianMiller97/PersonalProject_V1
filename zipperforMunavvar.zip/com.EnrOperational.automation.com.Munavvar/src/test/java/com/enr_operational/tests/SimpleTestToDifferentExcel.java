package com.enr_operational.tests;

import java.util.Random;

import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class SimpleTestToDifferentExcel extends TestBase {

	@Test
	public void createAccount() throws Exception {

		Random random = new Random();

		extentLogger = report.createTest("create Account Create trade relationship test");
		// info () --> to print a message
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");

		int low = 999;
		int high = 1999;
		int num = random.nextInt(high - low) + low;
		int acIdentifierNum = random.nextInt(10000000);
		String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.waitForPageToLoad(2);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
		Thread.sleep(2000);
		String shortName = "TestTest" + num + "";
		pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
		pages.getCreateAccountsTabAndPage().validationBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
		String name = "TestTestNew";
		pages.getCreateAccountsTabAndPage().name.sendKeys(name);
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
		String accountIdentifier = "00-" + einNumber;
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
		BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
		pages.getCreateAccountsTabAndPage().SaveButton.click();
		System.out.println(num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);

		// Write to Excel
		String path = "ENR_Operational_Excel_Updated_NoFormula.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Account");

		AccountBean account = new AccountBean();
		account.setActionFlag("C");
		account.setShortName(shortName);
		account.setName(name);
		account.setOrganizationType("Account");
		account.setAccountIdentifierValue(accountIdentifier);
		account.setExecutionStatus("pass");
		excelUtils.writeAccountToExcel(account);

//Add 1st Trade Relationship

		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
		pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Changes Only").click();
		pages.getCreateAccountTradeRelationshipPage().tradingType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Self").click();
		pages.getCreateAccountTradeRelationshipPage().tradeRelationshipAgreement.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("BCBSMA_DirectAccountDefaultsChangesOnly")
				.click();
		pages.getCreateAccountTradeRelationshipPage().nextBtn.click();

		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
		sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);

		String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
				.getAttribute("value");

		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().ISA06senderId);
		pages.getCreateAccountTradeRelationshipPage().ISA06senderId.sendKeys("" + num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().GSsenderId);
		pages.getCreateAccountTradeRelationshipPage().GSsenderId.sendKeys("" + num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);

		butil.waitForPageToLoad(1000);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
		butil.waitForPageToLoad(2000);

		excelUtils = new ExcelUtils(path, "Trade Relationship");

		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		trBean.setActionFlag("C");
		trBean.settRType("Inbound");
		trBean.setAccountShortName(shortName);
		trBean.setInBoundTRName(tradeRelationshipName);
		trBean.settRCategory("Change File By Self Submitter");
		trBean.setMode("Un-Monitored");
		trBean.setSenderId(String.valueOf(num));
		trBean.setInboundStatus("pass");
		trBean.setDivisionList("Un-Monitored");
		excelUtils.writeTradeRelationshipData(trBean);
	}
}
