package com.enr_operational.tests;

import java.util.Random;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ExcelUtils;

public class Create_Third_Party_Agent_Account_Test extends TestBase {
 
	@Test 
	public void createThirdPartyAgentAccount() throws Exception {
		extentLogger = report.createTest("create Third Party Agent Account test");
		// info () --> to print a message
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		for (int i = 0; i < 1; i++) {
			int num = BrowserUtils.getRundomNumInRange(999, 1999);
			int acIdentifierNum = BrowserUtils.getRundomNumInRange(1000000, 9000000);
			String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
			butil.waitForPageToLoad(2);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
			Thread.sleep(2000);
			String shortName = "TestTest" + num + "";
			pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
			pages.getCreateAccountsTabAndPage().validationBtn.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
			String name = "TestTestNew";
			pages.getCreateAccountsTabAndPage().name.sendKeys(name);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);
			butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
			pages.getCreateAccountsTabAndPage().organizationTypeInput.get(2).click();
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
			String accountIdentifier = "00-" + einNumber;
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
			BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
			pages.getCreateAccountsTabAndPage().SaveButton.click();
			System.out.println(num);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);

			// Write to Excel
			String path = "ENR_Operational_Excel_Updated_1212.xlsx";
			ExcelUtils excelUtils = new ExcelUtils(path, "Account");

			AccountBean account = new AccountBean();
			account.setActionFlag("C");
			account.setShortName(shortName);
			account.setName(name);
			account.setOrganizationType("Third Party Agent");
			account.setAccountIdentifierValue(accountIdentifier);
			account.setExecutionStatus("pass");
			excelUtils.writeAccountToExcel(account);
		}
	}
}
