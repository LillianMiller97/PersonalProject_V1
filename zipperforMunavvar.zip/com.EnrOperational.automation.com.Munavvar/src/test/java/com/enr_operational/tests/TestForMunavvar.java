package com.enr_operational.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.enr_operational.pages.CreateAccount_InternalContactPage;
import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ContactBean;
import com.enr_operational.utilities.Driver;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class TestForMunavvar extends TestBase {
	public static void main(String[] args) {
		String path = "ENR Regression - Updated_01162019.xls";
		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");
		List<TradeRelationship_Bean> accounts = excelUtils.getTradeRelData();
		System.out.println(accounts.get(0));
//		for (TradeRelationship_Bean ac : accounts) {
//			System.out.println(ac);
//		}

	}
}
