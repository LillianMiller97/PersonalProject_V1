package com.enr_operational.tests;

import java.util.Random;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;

import com.enr_operational.utilities.ExcelUtils;

public class Create_Sub_Account_Test extends TestBase {

	@Test
	public void createSub_Account() throws Exception {
		Random random = new Random();

//		extentLogger = report.createTest("create Sub-Account test");
//		// info () --> to print a message
//		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		for (int i = 0; i < 1; i++) {
			int low = 999;
			int high = 1999;
			int num = random.nextInt(high - low) + low;
			int acIdentifierNum = random.nextInt(10000000);
			String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
			butil.waitForPageToLoad(2);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
			Thread.sleep(2000);
			String shortName = "Test_Automation_" + num + "";
			pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
			pages.getCreateAccountsTabAndPage().validationBtn.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
			String name = "New_Test_Account";
			pages.getCreateAccountsTabAndPage().name.sendKeys(name);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);
           
			butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
			pages.getCreateAccountsTabAndPage().organizationTypeInput.get(1).click();
			pages.getCreateAccountsTabAndPage().parentAccountPicker.click();
			String parentAccount = "E2E_ENR_Release2_ vietnam";
			butil.waitForClickablility(By.xpath("//li[text()='" + parentAccount + "']"), 20);
			pages.getCreateAccountsTabAndPage().getParrentAccountOption(parentAccount).click();

			pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
			String accountIdentifier = "00-" + einNumber;
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
			BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
			pages.getCreateAccountsTabAndPage().SaveButton.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);
 
			// Write to Excel
			String path = "ENR_Operational_Excel_Updated_1212.xlsx";
			ExcelUtils excelUtils = new ExcelUtils(path, "Account");

			AccountBean account = new AccountBean();
			account.setActionFlag("C");
			account.setShortName(shortName);
			account.setName(name);
			account.setOrganizationType("Sub-Account");
			account.setParentAccount(parentAccount);
			account.setAccountIdentifierValue(accountIdentifier);
			account.setExecutionStatus("pass");
			excelUtils.writeAccountToExcel(account);
		}
		

	}

}