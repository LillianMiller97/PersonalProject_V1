package com.enr_operational.tests;

import java.util.Random;

import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class FullFileUpdate_ThirdPartyAgent_TradeRelationship_Test extends TestBase {

	@Test
	public void createAccountCreateTR() throws Exception {
		Random random = new Random();

		extentLogger = report.createTest("create Account Create trade relationship test");
		// info () --> to print a message
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		int low = 999;
		int high = 1999;
		int num = random.nextInt(high - low) + low;
		int acIdentifierNum = random.nextInt(10000000);
		String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.waitForPageToLoad(2);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
		Thread.sleep(2000);
		String shortName = "TestTest" + num + "";
		pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
		pages.getCreateAccountsTabAndPage().validationBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
		String name = "TestTestNew";
		pages.getCreateAccountsTabAndPage().name.sendKeys(name);
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
		String accountIdentifier = "00-" + einNumber;
		pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
		BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
		pages.getCreateAccountsTabAndPage().SaveButton.click();
		System.out.println(num);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);

		// Write to Excel
		String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Account");

		AccountBean account = new AccountBean();
		account.setActionFlag("C");
		account.setShortName(shortName);
		account.setName(name);
		account.setOrganizationType("Account");
		account.setAccountIdentifierValue(accountIdentifier);
		account.setExecutionStatus("pass");
		excelUtils.writeAccountToExcel(account);
	
	}
	public void loginAndCreateFullFileUpdate_ThirdPartyAgent_TradeRelationship() throws Exception {
		AccountBean account = new AccountBean();
		extentLogger = report.createTest("login and Create Full File Update_ThirdPartyAgent_TradeRelationship");
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
		butil.waitForPageToLoad(2000);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
		pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Full File Update").click();
		pages.getCreateAccountTradeRelationshipPage().tradingType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Third Party Agent").click();
		pages.getCreateAccountTradeRelationshipPage().tradeRelationshipFormat.click();
		pages.getCreateAccountTradeRelationshipPage().format834.click();
		pages.getCreateAccountTradeRelationshipPage().thirdPartyAgentInput.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("ADP").click();
		pages.getCreateAccountTradeRelationshipPage().agentTradeRelationshipAgreement.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("ADP_Maintenance_FullFile_06/13/2018_1").click();
		pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
		sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
		String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
				.getAttribute("value");
		butil.waitForVisibility(pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored"), 5);
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);

		String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");

		excelUtils = new ExcelUtils(path, "Trade Relationship");
		
		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		trBean.setActionFlag("C");
		trBean.settRType("Inbound");
		trBean.setAccountShortName(account.getShortName());
		trBean.setInBoundTRName(tradeRelationshipName);
		trBean.settRCategory("Full File By TPA");
		trBean.setMode("Un-Monitored");
		trBean.setSenderId("");
		trBean.setThirdPartyAgent("ADP");
		trBean.setAgentTradeRelationship("ADP_Maintenance_FullFile_06/13/2018_1");
		trBean.setInboundStatus("pass");

		excelUtils.writeTradeRelationshipData(trBean);
	   }
	}

