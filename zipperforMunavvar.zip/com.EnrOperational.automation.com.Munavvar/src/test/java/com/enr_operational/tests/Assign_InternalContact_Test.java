package com.enr_operational.tests;

import org.testng.annotations.Test;

import com.enr_operational.utilities.ContactBean;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.ReportSubscriptionType;

public class Assign_InternalContact_Test extends TestBase {

	@Test()
	public void createAccountCreateTR() throws Exception {
		//create a account and save its name
		// click on account based on name
		// put in the loop bellow code to create contacts
		
		extentLogger = report.createTest("Internal Contact Assign Test");
		// info () --> to print a message
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
		String firstAccountName = pages.getAccountDetailPage().firstAccount.getText();
		
        pages.getAccountDetailPage().firstAccount.click();
        pages.getAccountDetailPage().accountDetailContactTab.click();
        
        pages.getCreateAccounts_InternalContactPage().assignContactLink.click();
      //  pages.getCreateAccounts_InternalContactPage().internalContactArrowTriger.click();
        String contactByName="Markia";
        
        pages.getCreateAccounts_InternalContactPage().searchInput.sendKeys(contactByName);

        sutil.waitForStaleElement(pages.getCreateAccounts_InternalContactPage().getContactByName("Markia Laboy"));
        pages.getCreateAccounts_InternalContactPage().getContactByName("Markia Laboy").click();
        
        String roleInputValue="Business Analyst";
        pages.getCreateAccounts_InternalContactPage().roleInput.sendKeys(roleInputValue);
        pages.getCreateAccounts_InternalContactPage().rptSubMaintenanceSummaryCheckBox.click();
        pages.getCreateAccounts_InternalContactPage().rptSubAuditSummaryCheckBox.click();
        pages.getCreateAccounts_InternalContactPage().saveIntContBtn.click();
        
       
        String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils  excelUtils = new ExcelUtils(path, "Account");

		ContactBean contact = new ContactBean();
		contact.setFirstName("Markia");
		contact.setLastName("Laboy");
		contact.setEmail("markia.laboy@gmail.com");
		contact.setExt("234");
		contact.setPhone("774-5346272");
		contact.setTitle(roleInputValue);
		contact.setReportSubscription(ReportSubscriptionType.AUDIT_SUMMARY, ReportSubscriptionType.MAINTENANCE);
		excelUtils.writeContactToAccount(firstAccountName, contact);
	} 
}
