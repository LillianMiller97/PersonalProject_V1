package com.enr_operational.tests;

import java.util.Random;

import org.testng.annotations.Test;

import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class EmployerMaintenanceTradeRelationship_Test extends TestBase {

	@Test
	public void employerMaintenanceTradeRelationship() throws Exception {
 
		Random random = new Random(); 
		int num = random.nextInt(999);
		int acIdentifierNum = random.nextInt(10000000);
		String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);

		extentLogger = report.createTest("Employer Maintenance Trade Relationship");
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");

		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
		String accountShortName = pages.getAccountDetailPage().firstAccount.getText();
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
		butil.waitForPageToLoad(2000);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);

		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
		pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Employer Maintenance").click();
		pages.getCreateAccountTradeRelationshipPage().tradeRelationshipAgreement.click();
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("IntakeCMSEmployerMaintenance").click();
		pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
		sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
		
		String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
				.getAttribute("value");
		
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().senderId);
		String senderId = String.valueOf(num);
		String receiverId = String.valueOf(num)+"1";
		pages.getCreateAccountTradeRelationshipPage().senderId.sendKeys(senderId);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().receiverId);
		pages.getCreateAccountTradeRelationshipPage().receiverId.sendKeys(receiverId );
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
		butil.waitForPageToLoad(1000);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
		butil.waitForPageToLoad(2000);
		
		
		String path = "ENR_Operational_Excel_Updated_NoFormula.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");
		TradeRelationship_Bean trBean = new TradeRelationship_Bean();
		
		trBean.setActionFlag("C");
		trBean.settRType("Inbound");
		trBean.setAccountShortName(accountShortName);
		trBean.setInBoundTRName(tradeRelationshipName);
		trBean.settRCategory("Employer Maintenance");
		trBean.setMode("Un-Monitored");
		trBean.setSenderId(senderId);
		trBean.setInboundStatus("pass");
		excelUtils.writeTradeRelationshipData(trBean);
		
	}
}
