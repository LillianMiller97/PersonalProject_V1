package com.enr_operational.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.MasterTableBean;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class Create_Sub_Account_Create_Inbound_Employer_Maintenance_Trade_Relationships_Test extends TestBase {

	@Test
	public void create_Sub_Account_Create_Inbound_Employer_Maintenance_Trade_Relationships_Test() throws Exception {
	        
//		extentLogger = report.createTest("create Sub-Account Create Inbound Employer Maintenance Trade Relationships test");
//		// info () --> to print a message
//		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		for (int i = 0; i < 1; i++) {
		    int num = BrowserUtils.getRundomNumInRange(999, 1999);
			int acIdentifierNum = BrowserUtils.getRundomNumInRange(1000000, 9000000);
			String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
			butil.waitForPageToLoad(2);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
			Thread.sleep(2000);
			String shortName = "Test_Automation_" + num + "";
			pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
			pages.getCreateAccountsTabAndPage().validationBtn.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
			String name = "New_Test_Account";
			pages.getCreateAccountsTabAndPage().name.sendKeys(name);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);
			butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
			pages.getCreateAccountsTabAndPage().organizationTypeInput.get(1).click();
			pages.getCreateAccountsTabAndPage().parentAccountPicker.click();
			String parentAccount = "E2E_ENR_Release2_ vietnam";
			butil.waitForClickablility(By.xpath("//li[text()='" + parentAccount + "']"), 20);
			pages.getCreateAccountsTabAndPage().getParrentAccountOption(parentAccount).click();

			pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
			String accountIdentifier = "00-" + einNumber;
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
			BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
			pages.getCreateAccountsTabAndPage().SaveButton.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);

			// Write to Excel
			String path = "ENR_Operational_Excel_Updated_1212.xlsx";
			ExcelUtils excelUtils = new ExcelUtils(path, "Account");

			AccountBean account = new AccountBean();
			account.setActionFlag("C");
			account.setShortName(shortName);
			account.setName(name);
			account.setOrganizationType("Sub-Account");
			account.setParentAccount(parentAccount);
			account.setAccountIdentifierValue(accountIdentifier);
			account.setExecutionStatus("pass");
			excelUtils.writeAccountToExcel(account);

			butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
			Thread.sleep(200);
			pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
			pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Employer Maintenance").click();
			pages.getCreateAccountTradeRelationshipPage().tradeRelationshipAgreement.click();
			pages.getCreateAccountTradeRelationshipPage().getTradeOptions("IntakeCMSEmployerMaintenance").click();
			pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
			sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);

			String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
					.getAttribute("value");

			pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().senderId);
			
			String senderId = String.valueOf(BrowserUtils.getRundomNumInRange(100, 999));
			String receiverId = String.valueOf(num) + "1";
			pages.getCreateAccountTradeRelationshipPage().senderId.sendKeys(senderId);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().receiverId);
			pages.getCreateAccountTradeRelationshipPage().receiverId.sendKeys(receiverId);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
			butil.waitForPageToLoad(1000);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
			butil.waitForPageToLoad(2000);

			excelUtils = new ExcelUtils(path, "Trade Relationship");
			TradeRelationship_Bean trBean = new TradeRelationship_Bean();

			trBean.setActionFlag("C");
			trBean.settRType("Inbound");
			trBean.setAccountShortName(shortName);
			trBean.setInBoundTRName(tradeRelationshipName);
			trBean.settRCategory("Employer Maintenance");
			trBean.setMode("Un-Monitored");
			trBean.setSenderId(senderId);
			trBean.setInboundStatus("pass");
			excelUtils.writeTradeRelationshipData(trBean);
			
			excelUtils = new ExcelUtils(path, "Master Table");
			MasterTableBean masterTable = new MasterTableBean();
			masterTable.setExistingAccountName(account.getShortName());
			masterTable.setOrganizationType(account.getOrganizationType());
			masterTable.setTypeOfTR(trBean.gettRType());
			masterTable.settRName(trBean.getInBoundTRName());
			excelUtils.writeDataToMasterTable(masterTable);
		}

	}
}
