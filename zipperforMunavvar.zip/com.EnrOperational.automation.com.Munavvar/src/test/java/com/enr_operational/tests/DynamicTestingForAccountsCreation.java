package com.enr_operational.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.enr_operational.pages.CreateAccount_InternalContactPage;
import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ContactBean;
import com.enr_operational.utilities.Driver;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.MasterTableBean;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class DynamicTestingForAccountsCreation extends TestBase {
	
	@DataProvider(name = "Account")
	public Object[][] getExceldataTrade() throws Exception {
		//String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		String path = "ENR Regression - Updated_01162019.xls";
		ExcelUtils excelUtils = new ExcelUtils(path, "Account");
		List<AccountBean> accounts = excelUtils.getAccountData();
		Object[][] data = new Object[1][accounts.size()];
		for(int i = 0; i < accounts.size(); i++) {
			data[0][i] = accounts.get(i);
		}
		return data;
	}

	//@Test(dataProvider = "Account")
	public void test(AccountBean[] accounts) throws Exception {
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);

		int row = 1;
		
		System.out.println("Accounts to create: "+accounts.length);
		for (AccountBean account : accounts) {

			butil.waitForPageToLoad(2);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
			BrowserUtils.waitFor(2);

			String shortName = account.getShortName();
			pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
			pages.getCreateAccountsTabAndPage().validationBtn.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
			String name = account.getName();

			pages.getCreateAccountsTabAndPage().name.sendKeys(name);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);
			choseOrganizationType(account);
			if(!account.getRole().isEmpty()) {
				pages.getCreateAccountsTabAndPage().roleArrow.click();
				pages.getCreateAccountsTabAndPage().getOption(account.getRole());
			}
			
            BrowserUtils.waitFor(2);
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
			String accountIdentifier = account.getAccountIdentifierValue();
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);

			for (String indentifierStr : account.getOtherIdentifier()) {
				pages.getCreateAccountsTabAndPage().otherIdentifierLink.click();
				pages.getCreateAccountsTabAndPage().identifierLabelIntputList
						.get(pages.getCreateAccountsTabAndPage().identifierLabelIntputList.size() - 1).sendKeys("ETIN");
				Actions action = new Actions(Driver.getDriver());
				action.sendKeys(Keys.ARROW_UP).sendKeys(Keys.ENTER).build().perform();
				pages.getCreateAccountsTabAndPage().identifierValueIntputList
						.get(pages.getCreateAccountsTabAndPage().identifierValueIntputList.size() - 1)
						.sendKeys(indentifierStr);
			}

			BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
			pages.getCreateAccountsTabAndPage().SaveButton.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);

			if (!account.getContacts().isEmpty()) {
				pages.getAccountDetailPage().accountDetailContactTab.click();
				for (ContactBean contact : account.getContacts()) {
					try {
						BrowserUtils.waitFor(5);
						CreateAccount_InternalContactPage contPage = pages.getCreateAccounts_InternalContactPage();

						contPage.assignContactLink.click();
						contPage.searchInput
								.sendKeys(contact.getFirstName().trim() + " " + contact.getLastName().trim());

						BrowserUtils.waitFor(6);
						Actions action = new Actions(Driver.getDriver());
						action.sendKeys(Keys.ENTER).build().perform();

						String email = contPage.email.getText();
						String phone = contPage.phone.getAttribute("value");
						System.out.println("email: " + email);
						System.out.println("phone: " + phone);
						String role = contact.getTitle();

						contPage.roleInput.sendKeys(role);
						BrowserUtils.waitFor(5);
						action = new Actions(Driver.getDriver());
						action.sendKeys(Keys.ENTER).build().perform();
						BrowserUtils.waitFor(2);

						System.out.println(contact.getReportSubscriptionList());
						for (String index : contact.getReportSubscriptionList()) {
							WebElement rptSub = contPage.getReportSubscription(Integer.parseInt(index));
							if (rptSub != null) {
								rptSub.click();
							}
						}
						contPage.saveIntContBtn.click();

						System.out.println(
								contact.getFirstName() + " " + contact.getLastName() + " internal contact is created");
					} catch (Exception e) {
						System.out.println("Error during creation of " + contact.getFirstName() + " "
								+ contact.getLastName() + " contact");
						System.out.println("Please check if contact exist in internal system");
						e.printStackTrace();
					}

				}

			}
            row++;
            String path = "ENR Regression - Updated_01162019.xls";
			ExcelUtils excelUtils = new ExcelUtils(path, "Account");
			excelUtils.setCellData("pass", row, 2);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
		}

	}

	private void choseOrganizationType(AccountBean account) {
		switch (account.getOrganizationType()) {
		case "Account":
			break;
		case "Sub-Account":
			butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
			pages.getCreateAccountsTabAndPage().organizationTypeInput.get(1).click();
			pages.getCreateAccountsTabAndPage().parentAccountPicker.click();
			String parentAccount = account.getParentAccount();
			butil.waitForClickablility(By.xpath("//li[text()='" + parentAccount + "']"), 30);
			pages.getCreateAccountsTabAndPage().getParrentAccountOption(parentAccount).click();
			break;
		case "Third Party Agent":
			butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
			pages.getCreateAccountsTabAndPage().organizationTypeInput.get(2).click();
			break;
		default:
			throw new RuntimeException("Organization Type: " + account.getOrganizationType() + " is undefined");
		}
	}
	
	@Test
	public void trDynamicTest() throws Exception {
		//String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		String path = "ENR Regression - Updated_01162019.xls";
	//	String path = "ENR_Operational_Excel_Updated_1212.xlsx";
		ExcelUtils excelUtils = new ExcelUtils(path, "Trade Relationship");
		List<TradeRelationship_Bean> trs = excelUtils.getTradeRelData();
		
		ExcelUtils excelA = new ExcelUtils(path, "Account");
		excelA.getAccountData();
		
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		
		int row = 2;
		for(TradeRelationship_Bean tr : trs) {
			if(tr.getActionFlag().equalsIgnoreCase("C")) {
				
				System.out.println("----> Create <----");
				if(tr.gettRType().equalsIgnoreCase("Inbound")) {
					butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
					butil.waitForPageToLoad(2);
					
					try {
						if (pages.getCreateAccountTradeRelationshipPage().closeButton.isDisplayed()) {
							butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
						}
					}catch(Exception e) {
						System.out.println("Account wasn't open");
					}

					butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
					
					butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().searchKey);
					
					Actions action = new Actions(Driver.getDriver());
					action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();		
					pages.getEnrHomePage().searchField.sendKeys(tr.getAccountShortName()+Keys.ENTER);
					butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
					butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
					butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
					
					
					System.out.println("TR: "+ tr.gettRCategory());
					String tradeRelationshipName = "";
					switch(tr.gettRCategory().trim().toLowerCase()){
					case "change file by self submitter":
						System.out.println("inside if statement");
						pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Changes Only").click();
						pages.getCreateAccountTradeRelationshipPage().tradingType.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Self").click();
						pages.getCreateAccountTradeRelationshipPage().tradeRelationshipAgreement.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("BCBSMA_DirectAccountDefaultsChangesOnly").click();
						
						pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
						
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
						sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(tr.getMode()).click();
						
						pages.getCreateAccountTradeRelationshipPage().schedulRotation(tr.getSchedulerFrequency());
						
						String schValue = tr.getSchedulerValue();
						if(tr.getSchedulerFrequency().equals("Monthly")) {
							schValue = schValue.substring(0, schValue.length()-2);
						}
						pages.getCreateAccountTradeRelationshipPage().scheduleDay(schValue);					
						
						tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
								.getAttribute("value");	
						
					
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().ISA06senderId);
						pages.getCreateAccountTradeRelationshipPage().ISA06senderId.sendKeys(tr.getSenderId());
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().GSsenderId);
						pages.getCreateAccountTradeRelationshipPage().GSsenderId.sendKeys(tr.getSenderId());

						pages.getCreateAccountTradeRelationshipPage().accountIndetLocation.click();
						
						String accountIdentifierLoc = tr.getAccountIdentifierLocation().trim();
						System.out.println("LOc "+accountIdentifierLoc);
						butil.waitForClickablility(pages.getCreateAccountTradeRelationshipPage().getTradeOptions(accountIdentifierLoc),
								5);
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(accountIdentifierLoc).click();
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
						butil.waitForPageToLoad(1000);
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
						butil.waitForPageToLoad(2000);
						break;
						
					case "full file by self submitter":
						pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Full File Update").click();
						pages.getCreateAccountTradeRelationshipPage().tradingType.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Self").click();
						pages.getCreateAccountTradeRelationshipPage().tradeRelationshipFormat.click();
						pages.getCreateAccountTradeRelationshipPage().format834.click();
						pages.getCreateAccountTradeRelationshipPage().tradeRelationshipAgreement.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("BCBSMA_IntakeEmployerGroupFullFileUpdate").click();
						pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
						sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(tr.getMode()).click();
						
						pages.getCreateAccountTradeRelationshipPage().schedulRotation(tr.getSchedulerFrequency());
						schValue = tr.getSchedulerValue();
						if(tr.getSchedulerFrequency().equals("Monthly")) {
							schValue = schValue.substring(0, schValue.length()-2);
						}
						pages.getCreateAccountTradeRelationshipPage().scheduleDay(schValue);					
						
						tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
								.getAttribute("value");	
	
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().ISA06senderId);
						pages.getCreateAccountTradeRelationshipPage().ISA06senderId.sendKeys(tr.getSenderId());
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().GSsenderId);
						pages.getCreateAccountTradeRelationshipPage().GSsenderId.sendKeys(tr.getSenderId());

						pages.getCreateAccountTradeRelationshipPage().accountIndetLocation.click();
						
						accountIdentifierLoc = tr.getAccountIdentifierLocation().trim();
						System.out.println(accountIdentifierLoc);
						butil.waitForClickablility(pages.getCreateAccountTradeRelationshipPage().getTradeOptions(accountIdentifierLoc),
								5);
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(accountIdentifierLoc).click();
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
						butil.waitForPageToLoad(1000);
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
						butil.waitForPageToLoad(2000);
						break;
					case "change file by tpa":
						pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Changes Only").click();
						pages.getCreateAccountTradeRelationshipPage().tradingType.click();
						action = new Actions(Driver.getDriver());
						action.sendKeys(Keys.ARROW_DOWN);
						action.sendKeys(Keys.ENTER);
						action.build().perform();

						pages.getCreateAccountTradeRelationshipPage().tradeRelationshipFormat.click();
						pages.getCreateAccountTradeRelationshipPage().format834.click();
						pages.getCreateAccountTradeRelationshipPage().thirdPartyAgentInput.click();
						
						String agent = tr.getThirdPartyAgent();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(agent).click();
						
						pages.getCreateAccountTradeRelationshipPage().agentTradeRelationshipAgreement.click();
						action = new Actions(Driver.getDriver());
						action.sendKeys(Keys.ARROW_DOWN);
						action.sendKeys(Keys.ENTER);
						action.build().perform();
//						String agentTradeRel = "ADP_Stage_Maintenance_Changes_01/24/2019_1";
//						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(agentTradeRel).click();
						pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
						
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
						sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(tr.getMode()).click();
						
						pages.getCreateAccountTradeRelationshipPage().schedulRotation(tr.getSchedulerFrequency());
						schValue = tr.getSchedulerValue();
						if(tr.getSchedulerFrequency().equals("Monthly")) {
							schValue = schValue.substring(0, schValue.length()-2);
						}
						pages.getCreateAccountTradeRelationshipPage().scheduleDay(schValue);					
						
						tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
								.getAttribute("value");	
	
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);					
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
						butil.waitForPageToLoad(1000);
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
						butil.waitForPageToLoad(2000);
						break;
					case "full file by tpa":
						pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Full File Update").click();
						pages.getCreateAccountTradeRelationshipPage().tradingType.click();
						action = new Actions(Driver.getDriver());
						action.sendKeys(Keys.ARROW_DOWN);
						action.sendKeys(Keys.ENTER);
						action.build().perform();
						
						pages.getCreateAccountTradeRelationshipPage().tradeRelationshipFormat.click();
						pages.getCreateAccountTradeRelationshipPage().format834.click();
						pages.getCreateAccountTradeRelationshipPage().thirdPartyAgentInput.click();
						agent = tr.getThirdPartyAgent();
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(agent).click();
						pages.getCreateAccountTradeRelationshipPage().agentTradeRelationshipAgreement.click();		
						action = new Actions(Driver.getDriver());
						action.sendKeys(Keys.ARROW_DOWN);
						action.sendKeys(Keys.ENTER);
						action.build().perform();
						
						pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
						
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
						sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
						pages.getCreateAccountTradeRelationshipPage().getTradeOptions(tr.getMode()).click();
						
						pages.getCreateAccountTradeRelationshipPage().schedulRotation(tr.getSchedulerFrequency());
						schValue = tr.getSchedulerValue();
						if(tr.getSchedulerFrequency().equals("Monthly")) {
							schValue = schValue.substring(0, schValue.length()-2);
						}
						pages.getCreateAccountTradeRelationshipPage().scheduleDay(schValue);					
						
						tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
								.getAttribute("value");	
						
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
						butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
						
						
						break;
					}
					excelUtils = new ExcelUtils(path, "Master Table");
					MasterTableBean masterTable = new MasterTableBean();
					masterTable.setExistingAccountName(tr.getAccountShortName());
					masterTable.setOrganizationType(excelA.acMaping.get(tr.getAccountShortName()).getOrganizationType());
					masterTable.settRName(tradeRelationshipName);
					masterTable.setTypeOfTR(tr.gettRType());
					excelUtils.writeDataToMasterTable(masterTable);
					
					excelUtils = new ExcelUtils(path,"Trade Relationship");
					excelUtils.setCellData(tradeRelationshipName, row, 4);
					excelUtils.setCellData("pass", row, 30);
					butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
					
				}else {
					

					butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersTab);
					butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnerName);
					
					pages.getOutBound_TR_Page().partnerName.sendKeys(excelA.acMaping.get(tr.getAccountShortName()).getName());
					pages.getOutBound_TR_Page().partnerSearchButton.click();
					
					pages.getOutBound_TR_Page().getFirstAccountByName(excelA.acMaping.get(tr.getAccountShortName()).getName()).click();
					
					butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersRelationshipTab);
					Driver.getDriver().switchTo().frame("relationshipsFrame");
					Thread.sleep(1000);
					pages.getOutBound_TR_Page().pertnerAddTradeRelButton.click();
					butil.switchingFramesAndClickingToElement(pages.getOutBound_TR_Page().partnersNextButton);
					Thread.sleep(2000);
					pages.getOutBound_TR_Page().roleReceiver.click();
					
					String actualRelatedPartner = pages.getOutBound_TR_Page().roleRelatedPartner.getAttribute("value").trim();
					Assert.assertEquals(actualRelatedPartner, "Blue Cross Blue Shield of MA");
					Thread.sleep(1000);
					pages.getOutBound_TR_Page().partnersNextButton.click();

					pages.getOutBound_TR_Page().WizardTradeRelName.sendKeys(tr.getOutBoundTRName());
					pages.getOutBound_TR_Page().selectBUsinessDocumentByName("Enrollment Response File");
					pages.getOutBound_TR_Page().partnersNextButton.click();
					sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
					BrowserUtils.waitFor(2);
					pages.getOutBound_TR_Page().partnersNextButton.click();
					
					sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
					BrowserUtils.waitFor(2);
					pages.getOutBound_TR_Page().partnersNextButton.click();
				
					BrowserUtils.waitFor(2);
					pages.getOutBound_TR_Page().selectInterchangeReceiverIDByIndex(1);
					pages.getOutBound_TR_Page().selectInterchangeSenderIDByName("041045815 - ISA Identifier");
					sutil.waitForStaleElement(pages.getOutBound_TR_Page().partnersNextButton);
					pages.getOutBound_TR_Page().partnersNextButton.click();
					pages.getOutBound_TR_Page().finishBtn.click();
					Driver.getDriver().switchTo().frame("relationshipsFrame");
					boolean isRelExist = pages.getOutBound_TR_Page().isRelExist(tr.getOutBoundTRName());
					Assert.assertTrue(isRelExist);
					String actualOutboundResText = pages.getOutBound_TR_Page().outboundResText.getText();
					Assert.assertEquals(actualOutboundResText, "Outbound");		
					
					excelUtils = new ExcelUtils(path, "Master Table");
					MasterTableBean masterTable = new MasterTableBean();
					masterTable.setExistingAccountName(tr.getAccountShortName());
					masterTable.setOrganizationType(excelA.acMaping.get(tr.getAccountShortName()).getOrganizationType());
					masterTable.settRName(tr.getOutBoundTRName());
					masterTable.setTypeOfTR(tr.gettRType());
					excelUtils.writeDataToMasterTable(masterTable);
					
					excelUtils = new ExcelUtils(path,"Trade Relationship");
					excelUtils.setCellData("pass", row, 31);
				}
				
				row++;
			}else {
				if(tr.gettRType().equalsIgnoreCase("Inbound")) {
					butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
					butil.waitForPageToLoad(2);
					
					try {
						if (pages.getCreateAccountTradeRelationshipPage().closeButton.isDisplayed()) {
							butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
						}
					}catch(Exception e) {
						System.out.println("Account wasn't open");
					}

					butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
					
					butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().searchKey);
					
					Actions action = new Actions(Driver.getDriver());
					action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();		
					pages.getEnrHomePage().searchField.sendKeys(tr.getAccountShortName()+Keys.ENTER);
					butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
					butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
					butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().getTRByName(tr.getInBoundTRName()));
					butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
					sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
					pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Inactive").click();
					butil.switchingFramesAndClickingToElement(Driver.getDriver().findElement(By.xpath("//span[text()='Yes']")));
					butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
					butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().closeButton);
				}
			}
		}


	}

}
