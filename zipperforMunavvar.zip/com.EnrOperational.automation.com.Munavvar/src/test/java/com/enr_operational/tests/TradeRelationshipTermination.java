package com.enr_operational.tests;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.enr_operational.utilities.Driver;

public class TradeRelationshipTermination extends TestBase {

	@Test
	public void loginAndCreateThird_Party_Agent_Changes_Only_Trade_Relationship_For_First_Self_Account_Test()
			throws Exception {

//		extentLogger = report.createTest("login and Terminate Third Party Agent Changes Only Trade Relationship For First Self Account");
//		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
		
        butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);
		
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().searchKey);
		
		Actions action = new Actions(Driver.getDriver());
		action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();		
		pages.getEnrHomePage().searchField.sendKeys("dsd"+Keys.ENTER);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
		
		
		
		
		
		
//		String accountShortName = pages.getAccountDetailPage().firstAccount.getText();
//		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
		butil.waitForPageToLoad(2000);

		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().tradeRelationship);
		
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
		sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
		
		butil.waitForVisibility(pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Inactive"), 5);
		pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Inactive").click();
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);
		
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().allAccounts);	
		butil.switchingFramesAndClickingToElement(pages.getEnrHomePage().searchKey);
		
		action = new Actions(Driver.getDriver());
		action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();		
		pages.getEnrHomePage().searchField.sendKeys("Some ShortName "+Keys.ENTER);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().firstAccount);
		butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);
		butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
	}
}
