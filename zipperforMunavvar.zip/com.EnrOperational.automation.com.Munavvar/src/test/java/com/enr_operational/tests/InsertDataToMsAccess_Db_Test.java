package com.enr_operational.tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.testng.annotations.Test;

public class InsertDataToMsAccess_Db_Test{



	@Test
	public void insertingDataToMs_Access(){
		String databaseURL = "I://cis//Test Support Group//Automation//Selenium Projects//Mani//MS Access Database Dependencies//Database1.accdb";

		try (Connection connection = DriverManager.getConnection(databaseURL)) {

			Statement st = connection.createStatement();

			ResultSet rs = st.executeQuery("SELECT count(*) FROM MasterTable");

			rs.next();
			int rowCountBefore = rs.getInt(1);

			String sql = "INSERT INTO MasterTable (Existing_Account_Name, Organization_Type, Type_TR,TR_Name_Output,TR_Status,Last_Updated_Date,Last_Updated_By) VALUES (?,?,?,?,?,?,?)";
			Boolean bn = connection.isValid(3000);
			for (int i = 0; i < 3; i++) {
				try {
					if (bn = true) {

						break;
					}
				} catch (Exception e) {
					Thread.sleep(2000);
				}
			}

			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, "sTest_Automation_POC99");
			preparedStatement.setString(2, "Account");
			preparedStatement.setString(3, "OutBound");
			preparedStatement.setString(4, "Testout_land_Maintenance_Changes_11/20/2018_28");
			preparedStatement.setString(5, "A");
			preparedStatement.setString(6, "11/11/2013");
			preparedStatement.setString(7, "jaffe");

			int row = preparedStatement.executeUpdate();

			if (row > 0) {
				System.out.println("A row has been inserted successfully.");
			}

			ResultSet rsa = st.executeQuery("SELECT count(*) FROM MasterTable");

			rsa.next();
			int rowCountAfter = rsa.getInt(1);

			if (rowCountAfter > rowCountBefore) {
				System.out.println("successfully validated the table row count : Before inserting the row count is "
						+ rowCountBefore + "   and after inserting the row count is " + rowCountAfter);
			}

		} catch (Exception e) {
			System.out.println("Problem in loading or " + "registering MS Access JDBC driver   " + e.getMessage());
		}

	}
}
