package com.enr_operational.tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.CommonSeleniumUtils;
import com.enr_operational.utilities.ConfigurationReader;
import com.enr_operational.utilities.Credentials;
import com.enr_operational.utilities.Driver;
import Managers.PageObjectManager;

public abstract class TestBase {

	public Actions actions;

	public static String driverpath;
	public ExtentReports report;
	public ExtentTest extentLogger;
	public static ExtentHtmlReporter htmlreporter;
	public static com.aventstack.extentreports.ExtentReports extent;
	public static com.aventstack.extentreports.ExtentTest Logger;
	public static String imgpath;
	public static String proppath;
	protected PageObjectManager pages = new PageObjectManager();
	BrowserUtils butil = new BrowserUtils();
	CommonSeleniumUtils sutil = new CommonSeleniumUtils();
 
	public TestBase() {

		proppath = "I:<\\cis\\Test Support Group\\Automation\\ENR Operational\\configuration.properties>";
		driverpath = "I:\\cis\\Test Support Group\\Automation\\ENR Operational\\Driver_Jar\\chromedriver.exe";
		
	}

	@BeforeTest
	public void setUpTest() {
		Credentials.getCredentials();
//		report = new ExtentReports();
//		String filePath = System.getProperty("user.dir") + "/test-output/extent-report.html";
//		htmlreporter = new ExtentHtmlReporter(filePath);
//		report.attachReporter(htmlreporter);
//		report.setSystemInfo("browser", ConfigurationReader.getProperty("browser"));
//		report.setSystemInfo("OS", System.getProperty("os.name"));
//		htmlreporter.config().setReportName("EnrOperation Automated Test Reports");
		System.out.println("Before test");
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws InterruptedException {
		//actions = new Actions(Driver.getDriver());
		Driver.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Driver.getDriver().manage().window().fullscreen();
		Driver.getDriver().get(ConfigurationReader.getProperty("url"));  
		System.out.println("Before method");
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown(ITestResult result) throws Exception {
		// checking if the test method failed
	//	if (result.getStatus() == ITestResult.FAILURE) {
			// get screenshot using the utility method and save the location of the
			// screenshot
			//String screenshotLocation = BrowserUtils.getScreenshot(result.getName());

			// capture the name of test method
			//extentLogger.fail(result.getName());

			// add the screenshot to the report
			//extentLogger.addScreenCaptureFromPath(screenshotLocation);

			// capture the exception thrown
			//extentLogger.fail(result.getThrowable());

		//} else if (result.getStatus() == ITestResult.SKIP) {
			//extentLogger.skip("Test Case Skipped is " + result.getName());
		//}
		Driver.closeDriver();
		pages.reset();
	//}
	}
	@AfterTest
	public void tearDownTest() {
		//report.flush();
	}
}
