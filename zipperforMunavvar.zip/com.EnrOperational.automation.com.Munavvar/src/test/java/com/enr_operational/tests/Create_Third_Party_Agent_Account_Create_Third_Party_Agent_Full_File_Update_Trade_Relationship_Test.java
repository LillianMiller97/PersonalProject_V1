package com.enr_operational.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.enr_operational.utilities.AccountBean;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.Driver;
import com.enr_operational.utilities.ExcelUtils;
import com.enr_operational.utilities.MasterTableBean;
import com.enr_operational.utilities.TradeRelationship_Bean;

public class Create_Third_Party_Agent_Account_Create_Third_Party_Agent_Full_File_Update_Trade_Relationship_Test
		extends TestBase {

	@Test
	public void create_Third_Party_Agent_Account_Create_Third_Party_Agent_Full_File_Update_Trade_Relationship() throws Exception {
		extentLogger = report.createTest("Create Third Party Agent Account Create Third Party Agent Full File Update Trade Relationship test");
		// info () --> to print a message
		extentLogger.info("entering user credentials");
		pages.getLoginPage().loginApplication();
		pages.getLoginPage().verifyTitle("title");
		for (int i = 0; i < 1; i++) {
			int num = BrowserUtils.getRundomNumInRange(999, 1999);
			int acIdentifierNum = BrowserUtils.getRundomNumInRange(1000000, 9000000);
			String einNumber = BrowserUtils.modifyNumbers(acIdentifierNum);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().accountsTab);
			butil.waitForPageToLoad(2);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().createAccountButton);
			Thread.sleep(2000);
			String shortName = "Test_Automation_" + num + "";
			pages.getCreateAccountsTabAndPage().ShortName.sendKeys(shortName);
			pages.getCreateAccountsTabAndPage().validationBtn.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().name);
			String name = "New_Test_Account";
			pages.getCreateAccountsTabAndPage().name.sendKeys(name);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().organizationTypeArrow);
			butil.waitForClickablility(By.xpath("(//div[contains(@id, 'boundlist')])[2]//li"), 5);
			pages.getCreateAccountsTabAndPage().organizationTypeInput.get(2).click();
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.click();
			String accountIdentifier = "00-" + einNumber;
			pages.getCreateAccountsTabAndPage().accountIdentifierInput.sendKeys(accountIdentifier);
			BrowserUtils.hover(pages.getCreateAccountsTabAndPage().SaveButton);
			pages.getCreateAccountsTabAndPage().SaveButton.click();
			System.out.println(num);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountsTabAndPage().alertAccept);

			// Write to Excel
			String path = "ENR_Operational_Excel_Updated_1212.xlsx";
			ExcelUtils excelUtils = new ExcelUtils(path, "Account");

			AccountBean account = new AccountBean();
			account.setActionFlag("C");
			account.setShortName(shortName);
			account.setName(name);
			account.setOrganizationType("Third Party Agent");
			account.setAccountIdentifierValue(accountIdentifier);
			account.setExecutionStatus("pass");
			excelUtils.writeAccountToExcel(account);
			
			
			butil.switchingFramesAndClickingToElement(pages.getAccountDetailPage().accountDetailTradeRelationshipsTab);	
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().AddTrButton);
			pages.getCreateAccountTradeRelationshipPage().maintenanceType.click();
			pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Full File Update").click();
			pages.getCreateAccountTradeRelationshipPage().tradingType.click();
			Actions action = new Actions(Driver.getDriver());
			action.sendKeys(Keys.ARROW_DOWN);
			action.sendKeys(Keys.ENTER);
			action.build().perform();
			
			pages.getCreateAccountTradeRelationshipPage().tradeRelationshipFormat.click();
			pages.getCreateAccountTradeRelationshipPage().format834.click();
			pages.getCreateAccountTradeRelationshipPage().thirdPartyAgentInput.click();
			pages.getCreateAccountTradeRelationshipPage().getTradeOptions("ADP").click();
			pages.getCreateAccountTradeRelationshipPage().agentTradeRelationshipAgreement.click();
			pages.getCreateAccountTradeRelationshipPage().getTradeOptions("ADP_Maintenance_FullFile_06/13/2018_1")
					.click();
			pages.getCreateAccountTradeRelationshipPage().nextBtn.click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().mode);
			sutil.waitForStaleElement(pages.getCreateAccountTradeRelationshipPage().mode);
			String tradeRelationshipName = pages.getCreateAccountTradeRelationshipPage().tradeRelationshipName
					.getAttribute("value");
			butil.waitForVisibility(pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored"), 5);
			pages.getCreateAccountTradeRelationshipPage().getTradeOptions("Un-Monitored").click();
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().formatButton);
			butil.switchingFramesAndClickingToElement(pages.getCreateAccountTradeRelationshipPage().SaveTradeButton);

			excelUtils = new ExcelUtils(path, "Trade Relationship");
			TradeRelationship_Bean trBean = new TradeRelationship_Bean();
			trBean.setActionFlag("C");
			trBean.settRType("Inbound");
			trBean.setAccountShortName(account.getShortName());
			trBean.setInBoundTRName(tradeRelationshipName);
			trBean.settRCategory("Full File By TPA");
			trBean.setMode("Un-Monitored");
			trBean.setSenderId("");
			trBean.setThirdPartyAgent("ADP");
			trBean.setAgentTradeRelationship("ADP_Maintenance_FullFile_06/13/2018_1");
			trBean.setInboundStatus("pass");
			excelUtils.writeTradeRelationshipData(trBean);
			
			excelUtils = new ExcelUtils(path, "Master Table");
			MasterTableBean masterTable = new MasterTableBean();
			masterTable.setExistingAccountName(account.getShortName());
			masterTable.setOrganizationType(account.getOrganizationType());
			masterTable.setTypeOfTR(trBean.gettRType());
			masterTable.settRName(trBean.getInBoundTRName());		
			excelUtils.writeDataToMasterTable(masterTable);
		
		}
	}
}
