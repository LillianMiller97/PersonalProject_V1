package com.enroperation.identifiers;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.enr_operational.utilities.Driver;

public class CreateAccountTabPageIdentifier {

	public static final String creatAccountButtonIdentifierXpath = "(//span[.='Create New Account'])[1]";

	public static final String AccountsTabIdentifierXpath = "//span[.='Accounts']";

	public static final String ShortNameIdentifierXpath = "//input[@name='AccountShortName']";

	public static final String validationButtonIdentifierXpath = "//a[@title='Validate Account Short Name']";

	public static final String nameIdentifierXpath = "//input[@name='AccountName']";

	public static final String addressIdentifierXpath = "//input[@name='Street1']";

	public static final String cityIdentifierXpath = "//input[@name='City']";

	public static final String zipCodeIdentifier = "//input[@name='PostalCode']";

	public static final String AccountIdentifierInputXpath = "//input[@name='AccountIdentifierValue']";

	public static final String saveLinkIdentifierXpath = "//span[.='Save']/parent::span/parent::span/parent::a";

	public static final String AlertAcceptButtonXpath = "(//div[starts-with(@id,'messagebox')]//span[starts-with(@id,'button')])[4]";

	public static final String organizationTypeArrowXpath = "(//div[contains(@class,'x-form-arrow-trigger')])[4]";
	
	public static final String roleArrowXpath = "(//div[contains(@class,'x-form-arrow-trigger')])[7]";

	public static final String inputTextForOrganizationTypeXPath="//input[@name='OrganizationType']";
	
	public static final String parentAccountInputXpath = "//input[@name='ParentAccountTID']";
	
	public static final String organizationTypeInputXpath = "(//div[contains(@id, 'boundlist')])[2]//li";
	
	public static final String parentAccountPickerXpath="(//div[contains(@id,'trigger-picker')])[5]";
	
}
