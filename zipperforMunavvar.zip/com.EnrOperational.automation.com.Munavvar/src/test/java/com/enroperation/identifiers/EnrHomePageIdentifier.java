package com.enroperation.identifiers;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.enr_operational.utilities.Driver;

public class EnrHomePageIdentifier {

	public static final String enrHomePageTitleIdentifierID = "CommerceDesk_MainFrame";
	public static final String enrTransactionTabIdentifierXpath = "//a[@title='Transactions']";
	public static final String enr_EnrTransactionsTabIdentifierXpath = "//a[@title='ENR-Transactions']";
	public static final String enr_EnrollmentDashboardsTabIdentifierXpath = "//a[@title='Enrollment Dashboards']";
	public static final String enrMembersTabIdentifierXpath = "//a[@title='Members']";
	public static final String enrWorkflowTabIdentifierXpath = "//a[@title='Workflow']";
	
	public static final String allAccountsXpath="//a[@title='All Accounts']";
	public static final String assignedToMeLinkXpath="//a[@title='Assigned to Me']";
	public static final String portalAccessXpath="//span[text()='Portal Access:']";
	public static final String searchKeyXpath="//input[@name='searchKey']";
	public static final String searchKeyInputXpath="(//div[@class='x-form-text-wrap x-form-text-wrap-default'])[2]";
	
	
	public static final String searchIconXpath="//span[@style='background-image:url(images/actions/search.png);']";
	
	
	
}
