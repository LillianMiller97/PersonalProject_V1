package com.enroperation.identifiers;

import org.openqa.selenium.By;

public class CreateAccount_InternalContactPageIdentifier {

	public static final String assignIntContactBtnIdentifierXpath = "//a[@title='Assign']";

	public static final By cancelButtonLink = By.linkText("Cancel");

	public static final String internalContactArrowTrigerXpath = "//span[text()='Contact *']/parent::label/following-sibling::div/div/div[2]";

	public static final String roleInputName = "ContactRole";

	public static final String rptSubMaintenanceSummaryCheckBoxXpath = "//label[text()='Maintenance Summary']/preceding-sibling::input";

	public static final String rptSubMaintenanceDetailCheckBoxXpath = "//label[text()='Maintenance Detail']/preceding-sibling::input";
	
	public static final String rptSubAuditSummaryCheckBoxXpath = "//label[text()='Audit Summary']/preceding-sibling::input";
	
	public static final String rptSubAuditDetailCheckBoxXpath = "//label[text()='Audit Detail']/preceding-sibling::input";
	
	public static final String rptSubComplianceResultCheckBoxXpath = "//label[text()='Compliance Result']/preceding-sibling::input";
	
	public static final String saveIntContBtnXpath = "(//span[text()='Save'])[2]";

	public static final String unAssignIntContactBtnIdentifierXpath="//a[@title='Un-Assign']";
	
	
	// public static void
}
