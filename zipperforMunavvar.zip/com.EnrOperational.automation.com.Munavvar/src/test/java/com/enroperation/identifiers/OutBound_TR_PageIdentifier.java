package com.enroperation.identifiers;

public class OutBound_TR_PageIdentifier {

	public static final String partnerIconID = "icon-partners";

	public static final String partnerNameID = "SearchViewColumn_PartnerName";

	public static final String partnerSearchButtonID = "BtnSearch";

	public static final String partnersRelationshipTabXpath = "//span[text()='Relationships']";

	public static final String pertnerAddTradeRelButtonID = "AddTR";

	public static final String partnersNextButtonXpath = "//button[text()='Next']";

	public static final String partnersCancelButtonID = "Cancel";

	public static final String roleReceiverXpath = "//b[text()='Receiver']";

	public static final String roleSenderXpath = "//b[text()='Sender']";
	
	public static final String roleRelatedPartnerID = "RelatedPartner";
	
	public static final String WizardTradeRelNameID = "TRName";
	
	public static final String finishBtnID = "Finish";
	
	public static final String outboundResTextXpath = "//table[@class='gwt-ScrollTable-data']//tr[2]//td[4]//div";
	
}
