package com.enroperation.identifiers;

public class AccountDetailPageIdentifier {

	public static final String accountDetailHeaderId = "accountview-innerCt";

	public static final String accountDetailGeneralTabXpath = "//span[text()='General']";
	public static final String accountDetailContactTabXpath = "//span[text()='Contacts']";
	public static final String accountDetailTradeRelationshipsTabXpath = "//span[text()='Trade Relationships']";
	public static final String accountDetailTasksTabXpath = "//span[text()='Tasks']";
	public static final String accountDetailNotesTabXpath = "//span[text()='Notes']";
	public static final String accountDetailTransmissionsTabXpath = "//span[text()='Transmissions']";
	public static final String accountDetailPolicyUnitsTabXpath = "//span[text()='Policy Units']";
	public static final String accountDetailHistoryTabXpath = "//span[text()='History']";
	public static final String firstAccountOnListXpath = "(//a[contains(@href,'accounts')])[1]";
	public static final String accountViewBodyID = "accountview-body";
	public static final String addAccountLinkCSS = "a[title='Add']";

}
