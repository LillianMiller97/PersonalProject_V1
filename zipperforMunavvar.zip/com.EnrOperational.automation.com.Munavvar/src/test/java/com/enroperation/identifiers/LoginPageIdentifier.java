package com.enroperation.identifiers;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.enr_operational.tests.TestBase;
import com.enr_operational.utilities.BrowserUtils;
import com.enr_operational.utilities.ConfigurationReader;
import com.enr_operational.utilities.Driver;

public class LoginPageIdentifier{ //extends TestBase{
//
//	public LoginPageIdentifier() {
//	PageFactory.initElements(Driver.getDriver(), this);
//}
//   
    public static final String userNameIdentifierID = "Username";
	public static final String passwordIdentifierXpath = "//input[@name='password']";
	public static final String loginButtonIdentifierCss = ".login-button";

	public static final String userNameRecoveryIdentiferID = "UserNameRecovery";
	public static final String passwordRecoveryIdentiferID = "PasswordRecovery";
	

//	public void loginApplication() throws Exception {
//		// Intialization();
//		userNameIdentifierID.replaceAll("",ConfigurationReader.getProperty("username"));
//		passwordIdentifierXpath.replaceAll("",ConfigurationReader.getProperty("password"));
//		imgpath = BrowserUtils.CaptureScreenshot("Login.html");
//		System.out.println(imgpath);
//		driver.findElement(By.cssSelector(".login-button")).click();
//
//		System.out.println(driver.getTitle());
//	}
	}
