package com.enroperation.identifiers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TradeRelationshipTabPageIdentifier {

	public static final String tradeRelationSHipTabXpath = "(//span[.='Trade Relationships'])[3]";

	public static final String addTrButtonXpath = "//span[text()='Add']";

	public static final String addNoteButton = "//a[@title='Add Note']";

	public static final String closeButtonXpath = "//span[.='Close']/../span";

	public static final String addTradeRelationshipPopup = "addTradeRelationshipPopup";

	public static final String relationshipTypeRadioButton = "//tr[starts-with(@id,'ext-element')]";

	public static final String thirdPartyAgentInputXpath = "//span[text()='Third Party Agent*']";

	public static final String agentTradeRelationshipAgreementXpath = "//span[text()='Agent Trade Relationship*']";

	public static final String formatIdentifierForThirdPartyAgentXpath = "//span[text()='Format Identifiers']";

	public static final String maintenanceTypeXpath = "//span[text()='Maintenance Type']";

	public static final String tradingTypeXpath = "//span[text()='Trading Type']";

	public static final String tradeRelationshipAgreementXpath = "//span[text()='Agreement*']";

	public static final String nextBtnXpath = "//span[text()='Next']";

	public static final String modeXPath = "//input[@name='activityState']";

	public static final String formatButtonXPath = "//a[.='Format']";

	public static final String ISA06senderIdXpath = "//input[@name='ISASenderID']";

	public static final String GSsenderIdXpath = "//input[@name='GSSenderID']";

	public static final String SaveTradeButtonXpath = "(//span[text()='Save'])[2]";

	public static final String tradeRelationshipFormatXpath = "//span[text()='Format*']";

	public static final String format834Xpath = "//li[.='834']";

	public static final String linksForAccountsXpath = "//a[contains(@href,'accounts')]";

	public static final String senderIdXpath = "//input[@name='SenderID']";

	public static final String receiverIdXpath = "//input[@name='ReceiverID']";

	public static final String tradeRelationshipNameId = "trNameValueId-inputEl";

	public static final String agentTradeRelationshipAgreemtnXpath = "//span[text()='Agent Trade Relationship']/parent::label/following-sibling::div//a";

	public static final String senderIdValueXpath = "//span[text()='ISA 06 - Sender ID']/parent::label/following-sibling::div/div";

}
