package Managers;

import com.enr_operational.pages.AccountDetailPage;
import com.enr_operational.pages.CreateAccountInboundTradeRelationshipPage;
import com.enr_operational.pages.CreateAccount_InternalContactPage;
import com.enr_operational.pages.CreateAccountsTabAndPage;
import com.enr_operational.pages.EnrHomePage;
import com.enr_operational.pages.LoginPage;
import com.enr_operational.pages.OutBound_TR_Page;

public class PageObjectManager {
	private AccountDetailPage accountDetailPage;
	private CreateAccount_InternalContactPage internalContactPage;
	private CreateAccountsTabAndPage createAccountsTabAndPage;
	private CreateAccountInboundTradeRelationshipPage inboundTradeRelationshipPage;
	private EnrHomePage enrHomePage;
	private LoginPage loginPage;
	private OutBound_TR_Page outBoundTradeRelationshipPage;

	public AccountDetailPage getAccountDetailPage() {
		return (accountDetailPage == null) ? accountDetailPage = new AccountDetailPage() : accountDetailPage;
	}
 
	public CreateAccount_InternalContactPage getCreateAccounts_InternalContactPage() {
		return  internalContactPage = new CreateAccount_InternalContactPage();
	}

	public CreateAccountsTabAndPage getCreateAccountsTabAndPage() {
		return (createAccountsTabAndPage == null) ? createAccountsTabAndPage = new CreateAccountsTabAndPage()
				: createAccountsTabAndPage;
	}

	public CreateAccountInboundTradeRelationshipPage getCreateAccountTradeRelationshipPage() {
		return (inboundTradeRelationshipPage == null) ? inboundTradeRelationshipPage = new CreateAccountInboundTradeRelationshipPage()
				: inboundTradeRelationshipPage;
	}

	public EnrHomePage getEnrHomePage() {
		return (enrHomePage == null) ? enrHomePage = new EnrHomePage() : enrHomePage;
	}

	public LoginPage getLoginPage() {
		return (loginPage == null) ? loginPage = new LoginPage() : loginPage;
	}

	public OutBound_TR_Page getOutBound_TR_Page() {
		return (outBoundTradeRelationshipPage == null) ? outBoundTradeRelationshipPage = new OutBound_TR_Page() : outBoundTradeRelationshipPage;
	}
	
	public void reset() {
		this.accountDetailPage = null;
		this.internalContactPage = null;
		this.createAccountsTabAndPage = null;
		this.inboundTradeRelationshipPage = null;
		this.enrHomePage = null;
		this.loginPage = null;
		this.outBoundTradeRelationshipPage = null;
	}

}
